﻿namespace WindowsFormsApp2
{
    partial class FormOgretmen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormOgretmen));
            this.bunifuTileButton2 = new Bunifu.Framework.UI.BunifuTileButton();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btnOgretmenGiris = new Bunifu.Framework.UI.BunifuThinButton2();
            this.txtOgretmenAd = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.btnOgretmenCikis = new Bunifu.Framework.UI.BunifuThinButton2();
            this.txtOgretmenSifre = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.SuspendLayout();
            // 
            // bunifuTileButton2
            // 
            this.bunifuTileButton2.BackColor = System.Drawing.Color.SeaGreen;
            this.bunifuTileButton2.color = System.Drawing.Color.SeaGreen;
            this.bunifuTileButton2.colorActive = System.Drawing.Color.MediumSeaGreen;
            this.bunifuTileButton2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuTileButton2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F);
            this.bunifuTileButton2.ForeColor = System.Drawing.Color.White;
            this.bunifuTileButton2.Image = ((System.Drawing.Image)(resources.GetObject("bunifuTileButton2.Image")));
            this.bunifuTileButton2.ImagePosition = 20;
            this.bunifuTileButton2.ImageZoom = 50;
            this.bunifuTileButton2.LabelPosition = 80;
            this.bunifuTileButton2.LabelText = "ÖĞRETMEN GİRİŞİ";
            this.bunifuTileButton2.Location = new System.Drawing.Point(15, 15);
            this.bunifuTileButton2.Margin = new System.Windows.Forms.Padding(6);
            this.bunifuTileButton2.Name = "bunifuTileButton2";
            this.bunifuTileButton2.Size = new System.Drawing.Size(418, 365);
            this.bunifuTileButton2.TabIndex = 21;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label1.Location = new System.Drawing.Point(454, 15);
            this.label1.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(324, 44);
            this.label1.TabIndex = 24;
            this.label1.Text = "ÖĞRETMEN AD:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label2.Location = new System.Drawing.Point(454, 126);
            this.label2.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(147, 44);
            this.label2.TabIndex = 25;
            this.label2.Text = "ŞİFRE:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.Location = new System.Drawing.Point(464, 363);
            this.label3.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(0, 29);
            this.label3.TabIndex = 26;
            // 
            // btnOgretmenGiris
            // 
            this.btnOgretmenGiris.ActiveBorderThickness = 1;
            this.btnOgretmenGiris.ActiveCornerRadius = 20;
            this.btnOgretmenGiris.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.btnOgretmenGiris.ActiveForecolor = System.Drawing.Color.White;
            this.btnOgretmenGiris.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.btnOgretmenGiris.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btnOgretmenGiris.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnOgretmenGiris.BackgroundImage")));
            this.btnOgretmenGiris.ButtonText = "GİRİŞ YAP";
            this.btnOgretmenGiris.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnOgretmenGiris.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOgretmenGiris.ForeColor = System.Drawing.Color.SeaGreen;
            this.btnOgretmenGiris.IdleBorderThickness = 1;
            this.btnOgretmenGiris.IdleCornerRadius = 20;
            this.btnOgretmenGiris.IdleFillColor = System.Drawing.Color.White;
            this.btnOgretmenGiris.IdleForecolor = System.Drawing.Color.SeaGreen;
            this.btnOgretmenGiris.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.btnOgretmenGiris.Location = new System.Drawing.Point(892, 253);
            this.btnOgretmenGiris.Margin = new System.Windows.Forms.Padding(5);
            this.btnOgretmenGiris.Name = "btnOgretmenGiris";
            this.btnOgretmenGiris.Size = new System.Drawing.Size(446, 84);
            this.btnOgretmenGiris.TabIndex = 30;
            this.btnOgretmenGiris.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnOgretmenGiris.Click += new System.EventHandler(this.btnOgretmenGiris_Click);
            // 
            // txtOgretmenAd
            // 
            this.txtOgretmenAd.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtOgretmenAd.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtOgretmenAd.characterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtOgretmenAd.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtOgretmenAd.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.txtOgretmenAd.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtOgretmenAd.HintForeColor = System.Drawing.Color.Empty;
            this.txtOgretmenAd.HintText = "";
            this.txtOgretmenAd.isPassword = false;
            this.txtOgretmenAd.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtOgretmenAd.LineIdleColor = System.Drawing.Color.Gray;
            this.txtOgretmenAd.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtOgretmenAd.LineThickness = 3;
            this.txtOgretmenAd.Location = new System.Drawing.Point(788, 15);
            this.txtOgretmenAd.Margin = new System.Windows.Forms.Padding(4);
            this.txtOgretmenAd.MaxLength = 32767;
            this.txtOgretmenAd.Name = "txtOgretmenAd";
            this.txtOgretmenAd.Size = new System.Drawing.Size(550, 58);
            this.txtOgretmenAd.TabIndex = 27;
            this.txtOgretmenAd.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // btnOgretmenCikis
            // 
            this.btnOgretmenCikis.ActiveBorderThickness = 1;
            this.btnOgretmenCikis.ActiveCornerRadius = 20;
            this.btnOgretmenCikis.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.btnOgretmenCikis.ActiveForecolor = System.Drawing.Color.White;
            this.btnOgretmenCikis.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.btnOgretmenCikis.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btnOgretmenCikis.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnOgretmenCikis.BackgroundImage")));
            this.btnOgretmenCikis.ButtonText = "ÇIKIŞ";
            this.btnOgretmenCikis.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnOgretmenCikis.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOgretmenCikis.ForeColor = System.Drawing.Color.SeaGreen;
            this.btnOgretmenCikis.IdleBorderThickness = 1;
            this.btnOgretmenCikis.IdleCornerRadius = 20;
            this.btnOgretmenCikis.IdleFillColor = System.Drawing.Color.White;
            this.btnOgretmenCikis.IdleForecolor = System.Drawing.Color.SeaGreen;
            this.btnOgretmenCikis.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.btnOgretmenCikis.Location = new System.Drawing.Point(462, 253);
            this.btnOgretmenCikis.Margin = new System.Windows.Forms.Padding(5);
            this.btnOgretmenCikis.Name = "btnOgretmenCikis";
            this.btnOgretmenCikis.Size = new System.Drawing.Size(426, 84);
            this.btnOgretmenCikis.TabIndex = 29;
            this.btnOgretmenCikis.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnOgretmenCikis.Click += new System.EventHandler(this.btnOgretmenCikis_Click);
            // 
            // txtOgretmenSifre
            // 
            this.txtOgretmenSifre.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtOgretmenSifre.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtOgretmenSifre.characterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtOgretmenSifre.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtOgretmenSifre.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.txtOgretmenSifre.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtOgretmenSifre.HintForeColor = System.Drawing.Color.Empty;
            this.txtOgretmenSifre.HintText = "";
            this.txtOgretmenSifre.isPassword = true;
            this.txtOgretmenSifre.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtOgretmenSifre.LineIdleColor = System.Drawing.Color.Gray;
            this.txtOgretmenSifre.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtOgretmenSifre.LineThickness = 3;
            this.txtOgretmenSifre.Location = new System.Drawing.Point(788, 126);
            this.txtOgretmenSifre.Margin = new System.Windows.Forms.Padding(4);
            this.txtOgretmenSifre.MaxLength = 32767;
            this.txtOgretmenSifre.Name = "txtOgretmenSifre";
            this.txtOgretmenSifre.Size = new System.Drawing.Size(550, 60);
            this.txtOgretmenSifre.TabIndex = 28;
            this.txtOgretmenSifre.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // FormOgretmen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.ClientSize = new System.Drawing.Size(1386, 394);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btnOgretmenGiris);
            this.Controls.Add(this.txtOgretmenAd);
            this.Controls.Add(this.btnOgretmenCikis);
            this.Controls.Add(this.txtOgretmenSifre);
            this.Controls.Add(this.bunifuTileButton2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FormOgretmen";
            this.Text = "Form6";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Bunifu.Framework.UI.BunifuTileButton bunifuTileButton2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private Bunifu.Framework.UI.BunifuThinButton2 btnOgretmenGiris;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtOgretmenAd;
        private Bunifu.Framework.UI.BunifuThinButton2 btnOgretmenCikis;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtOgretmenSifre;
    }
}