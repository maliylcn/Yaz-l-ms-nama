﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data;
using MySql.Data.MySqlClient;
using windowsFormsApp1;
using WindowsFormsApp2;

namespace WindowsFormsApp2
{
    public partial class FormSinavOlustur : Form
    {
        public MySqlConnection con = new MySqlConnection("Server=localhost;Database=exam;Uid=root;Pwd='';");
        MySqlDataReader dr;
        MySqlCommand cmd;
        public FormSinavOlustur()
        {
            InitializeComponent();
        }

        private void FormSinavOlustur_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'examDataSet2.sorular' table. You can move, or remove it, as needed.
            this.sorularTableAdapter.Fill(this.examDataSet2.sorular);

        }

        private void btnEkle_Click(object sender, EventArgs e)
        {
            con.Open();
            cmd = new MySqlCommand("Insert into sınav(soru1_ID,soru2_ID,soru3_ID,soru4_ID,soru5_ID,soru6_ID,soru7_ID,soru8_ID,soru9_ID,soru10_ID) values ('" +txtSoru1.Text + "','" + txtSoru2.Text + "','" + txtSoru3.Text + "'," + txtSoru4.Text + "','" + txtSoru5.Text + "','" + txtSoru6.Text + "'," + txtSoru7.Text + "','" + txtSoru8.Text + "','" + txtSoru9.Text + "','" + txtSoru10.Text + "')", con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Ekleme başarılı...");
            con.Close();
            txtSoru1.Text = "";
            txtSoru2.Text = "";
            txtSoru3.Text = "";
            txtSoru4.Text = "";
            txtSoru5.Text = "";
            txtSoru6.Text = "";
            txtSoru7.Text = "";
            txtSoru8.Text = "";
            txtSoru9.Text = "";
            txtSoru10.Text = "";

        }

        private void btnGeri_Click(object sender, EventArgs e)
        {
            this.Close();
            Form4 fm = new Form4();
            fm.Show();
        }
    }
}
