﻿namespace WindowsFormsApp2
{
    partial class FormSoru
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormSoru));
            this.lblCevap = new System.Windows.Forms.Label();
            this.txtSoru9Cvp = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.dtGridSoru = new System.Windows.Forms.DataGridView();
            this.examDataSet3 = new WindowsFormsApp2.examDataSet3();
            this.sorularBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sorularTableAdapter = new WindowsFormsApp2.examDataSet3TableAdapters.sorularTableAdapter();
            this.examDataSet4 = new WindowsFormsApp2.examDataSet4();
            this.sınavBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sınavTableAdapter = new WindowsFormsApp2.examDataSet4TableAdapters.sınavTableAdapter();
            this.btnDogrula = new Bunifu.Framework.UI.BunifuThinButton2();
            this.txtSoru3Cvp = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.txtSoru1Cvp = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.txtSoru4Cvp = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.txtSoru7Cvp = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.txtSoru2Cvp = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.txtSoru8Cvp = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.txtSoru5Cvp = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.txtSoru6Cvp = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.txtSoru10Cvp = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.bunifuCustomLabel1 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel2 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel3 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel4 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel5 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel6 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel7 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel8 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel9 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel10 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.btnCık = new Bunifu.Framework.UI.BunifuThinButton2();
            this.bunifuCustomLabel11 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.btnSinavSec = new Bunifu.Framework.UI.BunifuThinButton2();
            this.examDataSet5 = new WindowsFormsApp2.examDataSet5();
            this.sınavBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.sınavTableAdapter1 = new WindowsFormsApp2.examDataSet5TableAdapters.sınavTableAdapter();
            this.txtSınavId = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.txtSoruID = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.btnSoruGetir = new Bunifu.Framework.UI.BunifuThinButton2();
            this.bunifuCustomLabel12 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dtGridSoru)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.examDataSet3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sorularBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.examDataSet4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sınavBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.examDataSet5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sınavBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblCevap
            // 
            this.lblCevap.AutoSize = true;
            this.lblCevap.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCevap.Location = new System.Drawing.Point(292, 616);
            this.lblCevap.Name = "lblCevap";
            this.lblCevap.Size = new System.Drawing.Size(244, 33);
            this.lblCevap.TabIndex = 6;
            this.lblCevap.Text = "CEVAPLARINIZ:";
            // 
            // txtSoru9Cvp
            // 
            this.txtSoru9Cvp.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtSoru9Cvp.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtSoru9Cvp.characterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtSoru9Cvp.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtSoru9Cvp.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.txtSoru9Cvp.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtSoru9Cvp.HintForeColor = System.Drawing.Color.Empty;
            this.txtSoru9Cvp.HintText = "";
            this.txtSoru9Cvp.isPassword = false;
            this.txtSoru9Cvp.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtSoru9Cvp.LineIdleColor = System.Drawing.Color.Gray;
            this.txtSoru9Cvp.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtSoru9Cvp.LineThickness = 3;
            this.txtSoru9Cvp.Location = new System.Drawing.Point(490, 949);
            this.txtSoru9Cvp.Margin = new System.Windows.Forms.Padding(4);
            this.txtSoru9Cvp.MaxLength = 32767;
            this.txtSoru9Cvp.Name = "txtSoru9Cvp";
            this.txtSoru9Cvp.Size = new System.Drawing.Size(180, 47);
            this.txtSoru9Cvp.TabIndex = 7;
            this.txtSoru9Cvp.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // dtGridSoru
            // 
            this.dtGridSoru.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtGridSoru.Location = new System.Drawing.Point(29, 172);
            this.dtGridSoru.Name = "dtGridSoru";
            this.dtGridSoru.RowHeadersWidth = 82;
            this.dtGridSoru.RowTemplate.Height = 33;
            this.dtGridSoru.Size = new System.Drawing.Size(1436, 144);
            this.dtGridSoru.TabIndex = 9;
            // 
            // examDataSet3
            // 
            this.examDataSet3.DataSetName = "examDataSet3";
            this.examDataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // sorularBindingSource
            // 
            this.sorularBindingSource.DataMember = "sorular";
            this.sorularBindingSource.DataSource = this.examDataSet3;
            // 
            // sorularTableAdapter
            // 
            this.sorularTableAdapter.ClearBeforeFill = true;
            // 
            // examDataSet4
            // 
            this.examDataSet4.DataSetName = "examDataSet4";
            this.examDataSet4.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // sınavBindingSource
            // 
            this.sınavBindingSource.DataMember = "sınav";
            this.sınavBindingSource.DataSource = this.examDataSet4;
            // 
            // sınavTableAdapter
            // 
            this.sınavTableAdapter.ClearBeforeFill = true;
            // 
            // btnDogrula
            // 
            this.btnDogrula.ActiveBorderThickness = 1;
            this.btnDogrula.ActiveCornerRadius = 20;
            this.btnDogrula.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.btnDogrula.ActiveForecolor = System.Drawing.Color.White;
            this.btnDogrula.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.btnDogrula.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btnDogrula.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnDogrula.BackgroundImage")));
            this.btnDogrula.ButtonText = "Doğrula";
            this.btnDogrula.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDogrula.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDogrula.ForeColor = System.Drawing.Color.SeaGreen;
            this.btnDogrula.IdleBorderThickness = 1;
            this.btnDogrula.IdleCornerRadius = 20;
            this.btnDogrula.IdleFillColor = System.Drawing.Color.White;
            this.btnDogrula.IdleForecolor = System.Drawing.Color.SeaGreen;
            this.btnDogrula.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.btnDogrula.Location = new System.Drawing.Point(796, 724);
            this.btnDogrula.Margin = new System.Windows.Forms.Padding(5);
            this.btnDogrula.Name = "btnDogrula";
            this.btnDogrula.Size = new System.Drawing.Size(336, 359);
            this.btnDogrula.TabIndex = 8;
            this.btnDogrula.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnDogrula.Click += new System.EventHandler(this.btnDogrula_Click);
            // 
            // txtSoru3Cvp
            // 
            this.txtSoru3Cvp.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtSoru3Cvp.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtSoru3Cvp.characterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtSoru3Cvp.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtSoru3Cvp.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.txtSoru3Cvp.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtSoru3Cvp.HintForeColor = System.Drawing.Color.Empty;
            this.txtSoru3Cvp.HintText = "";
            this.txtSoru3Cvp.isPassword = false;
            this.txtSoru3Cvp.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtSoru3Cvp.LineIdleColor = System.Drawing.Color.Gray;
            this.txtSoru3Cvp.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtSoru3Cvp.LineThickness = 3;
            this.txtSoru3Cvp.Location = new System.Drawing.Point(164, 868);
            this.txtSoru3Cvp.Margin = new System.Windows.Forms.Padding(4);
            this.txtSoru3Cvp.MaxLength = 32767;
            this.txtSoru3Cvp.Name = "txtSoru3Cvp";
            this.txtSoru3Cvp.Size = new System.Drawing.Size(180, 55);
            this.txtSoru3Cvp.TabIndex = 10;
            this.txtSoru3Cvp.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // txtSoru1Cvp
            // 
            this.txtSoru1Cvp.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtSoru1Cvp.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtSoru1Cvp.characterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtSoru1Cvp.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtSoru1Cvp.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.txtSoru1Cvp.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtSoru1Cvp.HintForeColor = System.Drawing.Color.Empty;
            this.txtSoru1Cvp.HintText = "";
            this.txtSoru1Cvp.isPassword = false;
            this.txtSoru1Cvp.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtSoru1Cvp.LineIdleColor = System.Drawing.Color.Gray;
            this.txtSoru1Cvp.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtSoru1Cvp.LineThickness = 3;
            this.txtSoru1Cvp.Location = new System.Drawing.Point(164, 707);
            this.txtSoru1Cvp.Margin = new System.Windows.Forms.Padding(4);
            this.txtSoru1Cvp.MaxLength = 32767;
            this.txtSoru1Cvp.Name = "txtSoru1Cvp";
            this.txtSoru1Cvp.Size = new System.Drawing.Size(180, 47);
            this.txtSoru1Cvp.TabIndex = 11;
            this.txtSoru1Cvp.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // txtSoru4Cvp
            // 
            this.txtSoru4Cvp.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtSoru4Cvp.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtSoru4Cvp.characterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtSoru4Cvp.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtSoru4Cvp.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.txtSoru4Cvp.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtSoru4Cvp.HintForeColor = System.Drawing.Color.Empty;
            this.txtSoru4Cvp.HintText = "";
            this.txtSoru4Cvp.isPassword = false;
            this.txtSoru4Cvp.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtSoru4Cvp.LineIdleColor = System.Drawing.Color.Gray;
            this.txtSoru4Cvp.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtSoru4Cvp.LineThickness = 3;
            this.txtSoru4Cvp.Location = new System.Drawing.Point(164, 949);
            this.txtSoru4Cvp.Margin = new System.Windows.Forms.Padding(4);
            this.txtSoru4Cvp.MaxLength = 32767;
            this.txtSoru4Cvp.Name = "txtSoru4Cvp";
            this.txtSoru4Cvp.Size = new System.Drawing.Size(180, 49);
            this.txtSoru4Cvp.TabIndex = 12;
            this.txtSoru4Cvp.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // txtSoru7Cvp
            // 
            this.txtSoru7Cvp.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtSoru7Cvp.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtSoru7Cvp.characterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtSoru7Cvp.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtSoru7Cvp.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.txtSoru7Cvp.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtSoru7Cvp.HintForeColor = System.Drawing.Color.Empty;
            this.txtSoru7Cvp.HintText = "";
            this.txtSoru7Cvp.isPassword = false;
            this.txtSoru7Cvp.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtSoru7Cvp.LineIdleColor = System.Drawing.Color.Gray;
            this.txtSoru7Cvp.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtSoru7Cvp.LineThickness = 3;
            this.txtSoru7Cvp.Location = new System.Drawing.Point(490, 785);
            this.txtSoru7Cvp.Margin = new System.Windows.Forms.Padding(4);
            this.txtSoru7Cvp.MaxLength = 32767;
            this.txtSoru7Cvp.Name = "txtSoru7Cvp";
            this.txtSoru7Cvp.Size = new System.Drawing.Size(180, 55);
            this.txtSoru7Cvp.TabIndex = 13;
            this.txtSoru7Cvp.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // txtSoru2Cvp
            // 
            this.txtSoru2Cvp.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtSoru2Cvp.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtSoru2Cvp.characterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtSoru2Cvp.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtSoru2Cvp.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.txtSoru2Cvp.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtSoru2Cvp.HintForeColor = System.Drawing.Color.Empty;
            this.txtSoru2Cvp.HintText = "";
            this.txtSoru2Cvp.isPassword = false;
            this.txtSoru2Cvp.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtSoru2Cvp.LineIdleColor = System.Drawing.Color.Gray;
            this.txtSoru2Cvp.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtSoru2Cvp.LineThickness = 3;
            this.txtSoru2Cvp.Location = new System.Drawing.Point(164, 789);
            this.txtSoru2Cvp.Margin = new System.Windows.Forms.Padding(4);
            this.txtSoru2Cvp.MaxLength = 32767;
            this.txtSoru2Cvp.Name = "txtSoru2Cvp";
            this.txtSoru2Cvp.Size = new System.Drawing.Size(180, 51);
            this.txtSoru2Cvp.TabIndex = 14;
            this.txtSoru2Cvp.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // txtSoru8Cvp
            // 
            this.txtSoru8Cvp.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtSoru8Cvp.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtSoru8Cvp.characterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtSoru8Cvp.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtSoru8Cvp.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.txtSoru8Cvp.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtSoru8Cvp.HintForeColor = System.Drawing.Color.Empty;
            this.txtSoru8Cvp.HintText = "";
            this.txtSoru8Cvp.isPassword = false;
            this.txtSoru8Cvp.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtSoru8Cvp.LineIdleColor = System.Drawing.Color.Gray;
            this.txtSoru8Cvp.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtSoru8Cvp.LineThickness = 3;
            this.txtSoru8Cvp.Location = new System.Drawing.Point(490, 871);
            this.txtSoru8Cvp.Margin = new System.Windows.Forms.Padding(4);
            this.txtSoru8Cvp.MaxLength = 32767;
            this.txtSoru8Cvp.Name = "txtSoru8Cvp";
            this.txtSoru8Cvp.Size = new System.Drawing.Size(180, 52);
            this.txtSoru8Cvp.TabIndex = 15;
            this.txtSoru8Cvp.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // txtSoru5Cvp
            // 
            this.txtSoru5Cvp.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtSoru5Cvp.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtSoru5Cvp.characterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtSoru5Cvp.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtSoru5Cvp.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.txtSoru5Cvp.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtSoru5Cvp.HintForeColor = System.Drawing.Color.Empty;
            this.txtSoru5Cvp.HintText = "";
            this.txtSoru5Cvp.isPassword = false;
            this.txtSoru5Cvp.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtSoru5Cvp.LineIdleColor = System.Drawing.Color.Gray;
            this.txtSoru5Cvp.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtSoru5Cvp.LineThickness = 3;
            this.txtSoru5Cvp.Location = new System.Drawing.Point(164, 1030);
            this.txtSoru5Cvp.Margin = new System.Windows.Forms.Padding(4);
            this.txtSoru5Cvp.MaxLength = 32767;
            this.txtSoru5Cvp.Name = "txtSoru5Cvp";
            this.txtSoru5Cvp.Size = new System.Drawing.Size(180, 53);
            this.txtSoru5Cvp.TabIndex = 16;
            this.txtSoru5Cvp.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // txtSoru6Cvp
            // 
            this.txtSoru6Cvp.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtSoru6Cvp.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtSoru6Cvp.characterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtSoru6Cvp.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtSoru6Cvp.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.txtSoru6Cvp.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtSoru6Cvp.HintForeColor = System.Drawing.Color.Empty;
            this.txtSoru6Cvp.HintText = "";
            this.txtSoru6Cvp.isPassword = false;
            this.txtSoru6Cvp.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtSoru6Cvp.LineIdleColor = System.Drawing.Color.Gray;
            this.txtSoru6Cvp.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtSoru6Cvp.LineThickness = 3;
            this.txtSoru6Cvp.Location = new System.Drawing.Point(490, 707);
            this.txtSoru6Cvp.Margin = new System.Windows.Forms.Padding(4);
            this.txtSoru6Cvp.MaxLength = 32767;
            this.txtSoru6Cvp.Name = "txtSoru6Cvp";
            this.txtSoru6Cvp.Size = new System.Drawing.Size(180, 47);
            this.txtSoru6Cvp.TabIndex = 17;
            this.txtSoru6Cvp.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // txtSoru10Cvp
            // 
            this.txtSoru10Cvp.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtSoru10Cvp.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtSoru10Cvp.characterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtSoru10Cvp.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtSoru10Cvp.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.txtSoru10Cvp.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtSoru10Cvp.HintForeColor = System.Drawing.Color.Empty;
            this.txtSoru10Cvp.HintText = "";
            this.txtSoru10Cvp.isPassword = false;
            this.txtSoru10Cvp.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtSoru10Cvp.LineIdleColor = System.Drawing.Color.Gray;
            this.txtSoru10Cvp.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtSoru10Cvp.LineThickness = 3;
            this.txtSoru10Cvp.Location = new System.Drawing.Point(490, 1032);
            this.txtSoru10Cvp.Margin = new System.Windows.Forms.Padding(4);
            this.txtSoru10Cvp.MaxLength = 32767;
            this.txtSoru10Cvp.Name = "txtSoru10Cvp";
            this.txtSoru10Cvp.Size = new System.Drawing.Size(180, 51);
            this.txtSoru10Cvp.TabIndex = 18;
            this.txtSoru10Cvp.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // bunifuCustomLabel1
            // 
            this.bunifuCustomLabel1.AutoSize = true;
            this.bunifuCustomLabel1.Location = new System.Drawing.Point(382, 1058);
            this.bunifuCustomLabel1.Name = "bunifuCustomLabel1";
            this.bunifuCustomLabel1.Size = new System.Drawing.Size(99, 25);
            this.bunifuCustomLabel1.TabIndex = 19;
            this.bunifuCustomLabel1.Text = "10. Soru:";
            // 
            // bunifuCustomLabel2
            // 
            this.bunifuCustomLabel2.AutoSize = true;
            this.bunifuCustomLabel2.Location = new System.Drawing.Point(382, 973);
            this.bunifuCustomLabel2.Name = "bunifuCustomLabel2";
            this.bunifuCustomLabel2.Size = new System.Drawing.Size(87, 25);
            this.bunifuCustomLabel2.TabIndex = 20;
            this.bunifuCustomLabel2.Text = "9. Soru:";
            // 
            // bunifuCustomLabel3
            // 
            this.bunifuCustomLabel3.AutoSize = true;
            this.bunifuCustomLabel3.Location = new System.Drawing.Point(382, 898);
            this.bunifuCustomLabel3.Name = "bunifuCustomLabel3";
            this.bunifuCustomLabel3.Size = new System.Drawing.Size(87, 25);
            this.bunifuCustomLabel3.TabIndex = 21;
            this.bunifuCustomLabel3.Text = "8. Soru:";
            // 
            // bunifuCustomLabel4
            // 
            this.bunifuCustomLabel4.AutoSize = true;
            this.bunifuCustomLabel4.Location = new System.Drawing.Point(382, 815);
            this.bunifuCustomLabel4.Name = "bunifuCustomLabel4";
            this.bunifuCustomLabel4.Size = new System.Drawing.Size(87, 25);
            this.bunifuCustomLabel4.TabIndex = 22;
            this.bunifuCustomLabel4.Text = "7. Soru:";
            // 
            // bunifuCustomLabel5
            // 
            this.bunifuCustomLabel5.AutoSize = true;
            this.bunifuCustomLabel5.Location = new System.Drawing.Point(382, 729);
            this.bunifuCustomLabel5.Name = "bunifuCustomLabel5";
            this.bunifuCustomLabel5.Size = new System.Drawing.Size(87, 25);
            this.bunifuCustomLabel5.TabIndex = 23;
            this.bunifuCustomLabel5.Text = "6. Soru:";
            // 
            // bunifuCustomLabel6
            // 
            this.bunifuCustomLabel6.AutoSize = true;
            this.bunifuCustomLabel6.Location = new System.Drawing.Point(24, 1058);
            this.bunifuCustomLabel6.Name = "bunifuCustomLabel6";
            this.bunifuCustomLabel6.Size = new System.Drawing.Size(87, 25);
            this.bunifuCustomLabel6.TabIndex = 24;
            this.bunifuCustomLabel6.Text = "5. Soru:";
            // 
            // bunifuCustomLabel7
            // 
            this.bunifuCustomLabel7.AutoSize = true;
            this.bunifuCustomLabel7.Location = new System.Drawing.Point(24, 973);
            this.bunifuCustomLabel7.Name = "bunifuCustomLabel7";
            this.bunifuCustomLabel7.Size = new System.Drawing.Size(87, 25);
            this.bunifuCustomLabel7.TabIndex = 25;
            this.bunifuCustomLabel7.Text = "4. Soru:";
            // 
            // bunifuCustomLabel8
            // 
            this.bunifuCustomLabel8.AutoSize = true;
            this.bunifuCustomLabel8.Location = new System.Drawing.Point(24, 898);
            this.bunifuCustomLabel8.Name = "bunifuCustomLabel8";
            this.bunifuCustomLabel8.Size = new System.Drawing.Size(87, 25);
            this.bunifuCustomLabel8.TabIndex = 26;
            this.bunifuCustomLabel8.Text = "3. Soru:";
            // 
            // bunifuCustomLabel9
            // 
            this.bunifuCustomLabel9.AutoSize = true;
            this.bunifuCustomLabel9.Location = new System.Drawing.Point(24, 815);
            this.bunifuCustomLabel9.Name = "bunifuCustomLabel9";
            this.bunifuCustomLabel9.Size = new System.Drawing.Size(87, 25);
            this.bunifuCustomLabel9.TabIndex = 27;
            this.bunifuCustomLabel9.Text = "2. Soru:";
            // 
            // bunifuCustomLabel10
            // 
            this.bunifuCustomLabel10.AutoSize = true;
            this.bunifuCustomLabel10.Location = new System.Drawing.Point(24, 729);
            this.bunifuCustomLabel10.Name = "bunifuCustomLabel10";
            this.bunifuCustomLabel10.Size = new System.Drawing.Size(87, 25);
            this.bunifuCustomLabel10.TabIndex = 28;
            this.bunifuCustomLabel10.Text = "1. Soru:";
            // 
            // btnCık
            // 
            this.btnCık.ActiveBorderThickness = 1;
            this.btnCık.ActiveCornerRadius = 20;
            this.btnCık.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.btnCık.ActiveForecolor = System.Drawing.Color.White;
            this.btnCık.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.btnCık.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btnCık.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnCık.BackgroundImage")));
            this.btnCık.ButtonText = "ÇIK";
            this.btnCık.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCık.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCık.ForeColor = System.Drawing.Color.SeaGreen;
            this.btnCık.IdleBorderThickness = 1;
            this.btnCık.IdleCornerRadius = 20;
            this.btnCık.IdleFillColor = System.Drawing.Color.White;
            this.btnCık.IdleForecolor = System.Drawing.Color.SeaGreen;
            this.btnCık.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.btnCık.Location = new System.Drawing.Point(1142, 724);
            this.btnCık.Margin = new System.Windows.Forms.Padding(5);
            this.btnCık.Name = "btnCık";
            this.btnCık.Size = new System.Drawing.Size(323, 359);
            this.btnCık.TabIndex = 29;
            this.btnCık.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnCık.Click += new System.EventHandler(this.btnCık_Click);
            // 
            // bunifuCustomLabel11
            // 
            this.bunifuCustomLabel11.AutoSize = true;
            this.bunifuCustomLabel11.Location = new System.Drawing.Point(65, 20);
            this.bunifuCustomLabel11.Name = "bunifuCustomLabel11";
            this.bunifuCustomLabel11.Size = new System.Drawing.Size(258, 75);
            this.bunifuCustomLabel11.TabIndex = 30;
            this.bunifuCustomLabel11.Text = "Sınav ID Seçiniz:\r\n\r\n1-10 arası bir sayı giriniz..\r\n";
            // 
            // btnSinavSec
            // 
            this.btnSinavSec.ActiveBorderThickness = 1;
            this.btnSinavSec.ActiveCornerRadius = 20;
            this.btnSinavSec.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.btnSinavSec.ActiveForecolor = System.Drawing.Color.White;
            this.btnSinavSec.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.btnSinavSec.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btnSinavSec.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSinavSec.BackgroundImage")));
            this.btnSinavSec.ButtonText = "SINAV SEÇ";
            this.btnSinavSec.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSinavSec.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSinavSec.ForeColor = System.Drawing.Color.SeaGreen;
            this.btnSinavSec.IdleBorderThickness = 1;
            this.btnSinavSec.IdleCornerRadius = 20;
            this.btnSinavSec.IdleFillColor = System.Drawing.Color.White;
            this.btnSinavSec.IdleForecolor = System.Drawing.Color.SeaGreen;
            this.btnSinavSec.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.btnSinavSec.Location = new System.Drawing.Point(1002, 14);
            this.btnSinavSec.Margin = new System.Windows.Forms.Padding(5);
            this.btnSinavSec.Name = "btnSinavSec";
            this.btnSinavSec.Size = new System.Drawing.Size(375, 93);
            this.btnSinavSec.TabIndex = 32;
            this.btnSinavSec.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnSinavSec.Click += new System.EventHandler(this.btnSinavSec_Click);
            // 
            // examDataSet5
            // 
            this.examDataSet5.DataSetName = "examDataSet5";
            this.examDataSet5.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // sınavBindingSource1
            // 
            this.sınavBindingSource1.DataMember = "sınav";
            this.sınavBindingSource1.DataSource = this.examDataSet5;
            // 
            // sınavTableAdapter1
            // 
            this.sınavTableAdapter1.ClearBeforeFill = true;
            // 
            // txtSınavId
            // 
            this.txtSınavId.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtSınavId.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtSınavId.characterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtSınavId.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtSınavId.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.txtSınavId.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtSınavId.HintForeColor = System.Drawing.Color.Empty;
            this.txtSınavId.HintText = "";
            this.txtSınavId.isPassword = false;
            this.txtSınavId.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtSınavId.LineIdleColor = System.Drawing.Color.Gray;
            this.txtSınavId.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtSınavId.LineThickness = 3;
            this.txtSınavId.Location = new System.Drawing.Point(451, 20);
            this.txtSınavId.Margin = new System.Windows.Forms.Padding(4);
            this.txtSınavId.MaxLength = 32767;
            this.txtSınavId.Name = "txtSınavId";
            this.txtSınavId.Size = new System.Drawing.Size(449, 64);
            this.txtSınavId.TabIndex = 34;
            this.txtSınavId.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // txtSoruID
            // 
            this.txtSoruID.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtSoruID.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtSoruID.characterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtSoruID.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtSoruID.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.txtSoruID.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtSoruID.HintForeColor = System.Drawing.Color.Empty;
            this.txtSoruID.HintText = "";
            this.txtSoruID.isPassword = false;
            this.txtSoruID.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtSoruID.LineIdleColor = System.Drawing.Color.Gray;
            this.txtSoruID.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtSoruID.LineThickness = 3;
            this.txtSoruID.Location = new System.Drawing.Point(451, 338);
            this.txtSoruID.Margin = new System.Windows.Forms.Padding(4);
            this.txtSoruID.MaxLength = 32767;
            this.txtSoruID.Name = "txtSoruID";
            this.txtSoruID.Size = new System.Drawing.Size(449, 83);
            this.txtSoruID.TabIndex = 35;
            this.txtSoruID.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // btnSoruGetir
            // 
            this.btnSoruGetir.ActiveBorderThickness = 1;
            this.btnSoruGetir.ActiveCornerRadius = 20;
            this.btnSoruGetir.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.btnSoruGetir.ActiveForecolor = System.Drawing.Color.White;
            this.btnSoruGetir.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.btnSoruGetir.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btnSoruGetir.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSoruGetir.BackgroundImage")));
            this.btnSoruGetir.ButtonText = "SORUYU GETİR";
            this.btnSoruGetir.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSoruGetir.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSoruGetir.ForeColor = System.Drawing.Color.SeaGreen;
            this.btnSoruGetir.IdleBorderThickness = 1;
            this.btnSoruGetir.IdleCornerRadius = 20;
            this.btnSoruGetir.IdleFillColor = System.Drawing.Color.White;
            this.btnSoruGetir.IdleForecolor = System.Drawing.Color.SeaGreen;
            this.btnSoruGetir.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.btnSoruGetir.Location = new System.Drawing.Point(1002, 324);
            this.btnSoruGetir.Margin = new System.Windows.Forms.Padding(5);
            this.btnSoruGetir.Name = "btnSoruGetir";
            this.btnSoruGetir.Size = new System.Drawing.Size(391, 97);
            this.btnSoruGetir.TabIndex = 36;
            this.btnSoruGetir.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnSoruGetir.Click += new System.EventHandler(this.btnSoruGetir_Click);
            // 
            // bunifuCustomLabel12
            // 
            this.bunifuCustomLabel12.AutoSize = true;
            this.bunifuCustomLabel12.Location = new System.Drawing.Point(52, 368);
            this.bunifuCustomLabel12.Name = "bunifuCustomLabel12";
            this.bunifuCustomLabel12.Size = new System.Drawing.Size(345, 25);
            this.bunifuCustomLabel12.TabIndex = 37;
            this.bunifuCustomLabel12.Text = "Görmek İstediğiniz Soru ID Giriniz :";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(29, 441);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 82;
            this.dataGridView1.RowTemplate.Height = 33;
            this.dataGridView1.Size = new System.Drawing.Size(1436, 146);
            this.dataGridView1.TabIndex = 38;
            // 
            // FormSoru
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.ClientSize = new System.Drawing.Size(1492, 1242);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.bunifuCustomLabel12);
            this.Controls.Add(this.btnSoruGetir);
            this.Controls.Add(this.txtSoruID);
            this.Controls.Add(this.txtSınavId);
            this.Controls.Add(this.btnSinavSec);
            this.Controls.Add(this.bunifuCustomLabel11);
            this.Controls.Add(this.btnCık);
            this.Controls.Add(this.bunifuCustomLabel10);
            this.Controls.Add(this.bunifuCustomLabel9);
            this.Controls.Add(this.bunifuCustomLabel8);
            this.Controls.Add(this.bunifuCustomLabel7);
            this.Controls.Add(this.bunifuCustomLabel6);
            this.Controls.Add(this.bunifuCustomLabel5);
            this.Controls.Add(this.bunifuCustomLabel4);
            this.Controls.Add(this.bunifuCustomLabel3);
            this.Controls.Add(this.bunifuCustomLabel2);
            this.Controls.Add(this.bunifuCustomLabel1);
            this.Controls.Add(this.txtSoru10Cvp);
            this.Controls.Add(this.txtSoru6Cvp);
            this.Controls.Add(this.txtSoru5Cvp);
            this.Controls.Add(this.txtSoru8Cvp);
            this.Controls.Add(this.txtSoru2Cvp);
            this.Controls.Add(this.txtSoru7Cvp);
            this.Controls.Add(this.txtSoru4Cvp);
            this.Controls.Add(this.txtSoru1Cvp);
            this.Controls.Add(this.txtSoru3Cvp);
            this.Controls.Add(this.dtGridSoru);
            this.Controls.Add(this.btnDogrula);
            this.Controls.Add(this.txtSoru9Cvp);
            this.Controls.Add(this.lblCevap);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FormSoru";
            this.Text = "FormSoru";
            this.Load += new System.EventHandler(this.FormSoru_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dtGridSoru)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.examDataSet3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sorularBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.examDataSet4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sınavBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.examDataSet5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sınavBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblCevap;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtSoru9Cvp;
        private Bunifu.Framework.UI.BunifuThinButton2 btnDogrula;
        private System.Windows.Forms.DataGridView dtGridSoru;
        private examDataSet3 examDataSet3;
        private System.Windows.Forms.BindingSource sorularBindingSource;
        private examDataSet3TableAdapters.sorularTableAdapter sorularTableAdapter;
        private examDataSet4 examDataSet4;
        private System.Windows.Forms.BindingSource sınavBindingSource;
        private examDataSet4TableAdapters.sınavTableAdapter sınavTableAdapter;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtSoru3Cvp;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtSoru1Cvp;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtSoru4Cvp;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtSoru7Cvp;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtSoru2Cvp;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtSoru8Cvp;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtSoru5Cvp;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtSoru6Cvp;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtSoru10Cvp;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel1;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel2;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel3;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel4;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel5;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel6;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel7;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel8;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel9;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel10;
        private Bunifu.Framework.UI.BunifuThinButton2 btnCık;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel11;
        private Bunifu.Framework.UI.BunifuThinButton2 btnSinavSec;
        private examDataSet5 examDataSet5;
        private System.Windows.Forms.BindingSource sınavBindingSource1;
        private examDataSet5TableAdapters.sınavTableAdapter sınavTableAdapter1;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtSınavId;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtSoruID;
        private Bunifu.Framework.UI.BunifuThinButton2 btnSoruGetir;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel12;
        private System.Windows.Forms.DataGridView dataGridView1;
    }
}