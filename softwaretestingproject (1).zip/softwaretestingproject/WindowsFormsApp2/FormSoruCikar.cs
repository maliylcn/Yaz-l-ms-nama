﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data;
using MySql.Data.MySqlClient;
using windowsFormsApp1;
using WindowsFormsApp2;

namespace WindowsFormsApp2
{
    public partial class FormSoruCikar : Form
    {
        public MySqlConnection con = new MySqlConnection("Server=localhost;Database=exam;Uid=root;Pwd='';");
        MySqlDataReader dr;
        MySqlCommand cmd;
        public FormSoruCikar()
        {
            InitializeComponent();
        }

        public void FormSoruCikar_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'examDataSet2.sorular' table. You can move, or remove it, as needed.
            this.sorularTableAdapter.Fill(this.examDataSet2.sorular);
            
        }

        private void btnSil_Click(object sender, EventArgs e)
        {
            con.Open();
            cmd = new MySqlCommand("DELETE FROM `sorular` WHERE id='" + txtSoruId.Text + "'", con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("silme başarılı...");
            con.Close();
            txtSoruId.Text = "";
            this.sorularTableAdapter.Fill(this.examDataSet2.sorular);

        }
        

        private void btnGeriDon_Click(object sender, EventArgs e)
        {
            this.Close();
            Form4 fm = new Form4();
            fm.Show();
        }
    }
}
