﻿namespace windowsFormsApp1
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form4));
            this.btnSoruEkle = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btnSoruCıkar = new Bunifu.Framework.UI.BunifuThinButton2();
            this.bunifuCustomLabel1 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.btnSinavOlustur = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btnGeri = new Bunifu.Framework.UI.BunifuThinButton2();
            this.SuspendLayout();
            // 
            // btnSoruEkle
            // 
            this.btnSoruEkle.ActiveBorderThickness = 1;
            this.btnSoruEkle.ActiveCornerRadius = 20;
            this.btnSoruEkle.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.btnSoruEkle.ActiveForecolor = System.Drawing.Color.White;
            this.btnSoruEkle.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.btnSoruEkle.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btnSoruEkle.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSoruEkle.BackgroundImage")));
            this.btnSoruEkle.ButtonText = "SORU EKLE";
            this.btnSoruEkle.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSoruEkle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSoruEkle.ForeColor = System.Drawing.Color.SeaGreen;
            this.btnSoruEkle.IdleBorderThickness = 1;
            this.btnSoruEkle.IdleCornerRadius = 20;
            this.btnSoruEkle.IdleFillColor = System.Drawing.Color.White;
            this.btnSoruEkle.IdleForecolor = System.Drawing.Color.SeaGreen;
            this.btnSoruEkle.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.btnSoruEkle.Location = new System.Drawing.Point(64, 263);
            this.btnSoruEkle.Margin = new System.Windows.Forms.Padding(5);
            this.btnSoruEkle.Name = "btnSoruEkle";
            this.btnSoruEkle.Size = new System.Drawing.Size(548, 131);
            this.btnSoruEkle.TabIndex = 2;
            this.btnSoruEkle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnSoruEkle.Click += new System.EventHandler(this.btnSoruEkle_Click);
            // 
            // btnSoruCıkar
            // 
            this.btnSoruCıkar.ActiveBorderThickness = 1;
            this.btnSoruCıkar.ActiveCornerRadius = 20;
            this.btnSoruCıkar.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.btnSoruCıkar.ActiveForecolor = System.Drawing.Color.White;
            this.btnSoruCıkar.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.btnSoruCıkar.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btnSoruCıkar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSoruCıkar.BackgroundImage")));
            this.btnSoruCıkar.ButtonText = "SORU ÇIKAR";
            this.btnSoruCıkar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSoruCıkar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSoruCıkar.ForeColor = System.Drawing.Color.SeaGreen;
            this.btnSoruCıkar.IdleBorderThickness = 1;
            this.btnSoruCıkar.IdleCornerRadius = 20;
            this.btnSoruCıkar.IdleFillColor = System.Drawing.Color.White;
            this.btnSoruCıkar.IdleForecolor = System.Drawing.Color.SeaGreen;
            this.btnSoruCıkar.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.btnSoruCıkar.Location = new System.Drawing.Point(64, 404);
            this.btnSoruCıkar.Margin = new System.Windows.Forms.Padding(5);
            this.btnSoruCıkar.Name = "btnSoruCıkar";
            this.btnSoruCıkar.Size = new System.Drawing.Size(548, 131);
            this.btnSoruCıkar.TabIndex = 3;
            this.btnSoruCıkar.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnSoruCıkar.Click += new System.EventHandler(this.btnSoruCıkar_Click);
            // 
            // bunifuCustomLabel1
            // 
            this.bunifuCustomLabel1.AutoSize = true;
            this.bunifuCustomLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel1.Location = new System.Drawing.Point(14, 20);
            this.bunifuCustomLabel1.Name = "bunifuCustomLabel1";
            this.bunifuCustomLabel1.Size = new System.Drawing.Size(630, 210);
            this.bunifuCustomLabel1.TabIndex = 4;
            this.bunifuCustomLabel1.Text = "           HOŞ GELDİNİZ \r\n\r\nBu ekrandan seçimizi yaparak \r\nsoru ekleme ve çıkarma" +
    " işlemlerini \r\ngerçekleştirebilirsiniz...";
            // 
            // btnSinavOlustur
            // 
            this.btnSinavOlustur.ActiveBorderThickness = 1;
            this.btnSinavOlustur.ActiveCornerRadius = 20;
            this.btnSinavOlustur.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.btnSinavOlustur.ActiveForecolor = System.Drawing.Color.White;
            this.btnSinavOlustur.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.btnSinavOlustur.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btnSinavOlustur.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSinavOlustur.BackgroundImage")));
            this.btnSinavOlustur.ButtonText = "SINAV OLUŞTUR";
            this.btnSinavOlustur.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSinavOlustur.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSinavOlustur.ForeColor = System.Drawing.Color.SeaGreen;
            this.btnSinavOlustur.IdleBorderThickness = 1;
            this.btnSinavOlustur.IdleCornerRadius = 20;
            this.btnSinavOlustur.IdleFillColor = System.Drawing.Color.White;
            this.btnSinavOlustur.IdleForecolor = System.Drawing.Color.SeaGreen;
            this.btnSinavOlustur.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.btnSinavOlustur.Location = new System.Drawing.Point(64, 545);
            this.btnSinavOlustur.Margin = new System.Windows.Forms.Padding(5);
            this.btnSinavOlustur.Name = "btnSinavOlustur";
            this.btnSinavOlustur.Size = new System.Drawing.Size(548, 139);
            this.btnSinavOlustur.TabIndex = 5;
            this.btnSinavOlustur.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnSinavOlustur.Click += new System.EventHandler(this.btnSinavOlustur_Click);
            // 
            // btnGeri
            // 
            this.btnGeri.ActiveBorderThickness = 1;
            this.btnGeri.ActiveCornerRadius = 20;
            this.btnGeri.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.btnGeri.ActiveForecolor = System.Drawing.Color.White;
            this.btnGeri.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.btnGeri.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btnGeri.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnGeri.BackgroundImage")));
            this.btnGeri.ButtonText = "GERİ DÖN";
            this.btnGeri.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnGeri.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGeri.ForeColor = System.Drawing.Color.SeaGreen;
            this.btnGeri.IdleBorderThickness = 1;
            this.btnGeri.IdleCornerRadius = 20;
            this.btnGeri.IdleFillColor = System.Drawing.Color.White;
            this.btnGeri.IdleForecolor = System.Drawing.Color.SeaGreen;
            this.btnGeri.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.btnGeri.Location = new System.Drawing.Point(64, 694);
            this.btnGeri.Margin = new System.Windows.Forms.Padding(5);
            this.btnGeri.Name = "btnGeri";
            this.btnGeri.Size = new System.Drawing.Size(548, 125);
            this.btnGeri.TabIndex = 6;
            this.btnGeri.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnGeri.Click += new System.EventHandler(this.btnGeri_Click);
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.ClientSize = new System.Drawing.Size(652, 833);
            this.Controls.Add(this.btnGeri);
            this.Controls.Add(this.btnSinavOlustur);
            this.Controls.Add(this.bunifuCustomLabel1);
            this.Controls.Add(this.btnSoruCıkar);
            this.Controls.Add(this.btnSoruEkle);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "Form4";
            this.Text = "Form4";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private Bunifu.Framework.UI.BunifuThinButton2 btnSoruEkle;
        private Bunifu.Framework.UI.BunifuThinButton2 btnSoruCıkar;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel1;
        private Bunifu.Framework.UI.BunifuThinButton2 btnSinavOlustur;
        private Bunifu.Framework.UI.BunifuThinButton2 btnGeri;
    }
}