﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data;
using MySql.Data.MySqlClient;

namespace WindowsFormsApp2
{
    
    public partial class FrmSonuc : Form
    {
        public MySqlConnection con = new MySqlConnection("Server=localhost;Database=exam;Uid=root;Pwd='';");
        MySqlDataReader dr;
        MySqlCommand cmd;
        public FrmSonuc()
        {
            InitializeComponent();
        }

        private void FrmSonuc_Load(object sender, EventArgs e)
        {
            con.Open();
            string kayit = "SELECT id from sınav ";
            //musteriler tablosundaki tüm kayıtları çekecek olan sql sorgusu.
            MySqlCommand komut = new MySqlCommand(kayit, con);
            //Sorgumuzu ve baglantimizi parametre olarak alan bir SqlCommand nesnesi oluşturuyoruz.
            MySqlDataAdapter da = new MySqlDataAdapter(komut);
            //SqlDataAdapter sınıfı verilerin databaseden aktarılması işlemini gerçekleştirir.
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            //Formumuzdaki DataGridViewin veri kaynağını oluşturduğumuz tablo olarak gösteriyoruz.
            con.Close();
        }

        private void btnCvpGetir_Click(object sender, EventArgs e)
        {
            con.Open();
            string kayit = "SELECT cvp1,cvp2,cvp3,cvp4,cvp5,cvp6,cvp7,cvp8,cvp9,cvp10 from sonuclar where sinav_id='" +txtSinavID.Text+"' ";
            //musteriler tablosundaki tüm kayıtları çekecek olan sql sorgusu.
            MySqlCommand komut = new MySqlCommand(kayit, con);
            //Sorgumuzu ve baglantimizi parametre olarak alan bir SqlCommand nesnesi oluşturuyoruz.
            MySqlDataAdapter da = new MySqlDataAdapter(komut);
            //SqlDataAdapter sınıfı verilerin databaseden aktarılması işlemini gerçekleştirir.
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView2.DataSource = dt;
            //Formumuzdaki DataGridViewin veri kaynağını oluşturduğumuz tablo olarak gösteriyoruz.
            con.Close();
        }

        private void btnGeri_Click(object sender, EventArgs e)
        {
            this.Close();
            OgrenciSayfa fm = new OgrenciSayfa();
            fm.Show();
        }
    }
}
