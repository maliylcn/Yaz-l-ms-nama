﻿namespace WindowsFormsApp2
{
    partial class FrmSonuc
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmSonuc));
            this.label2 = new System.Windows.Forms.Label();
            this.txtSinavID = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.btnCvpGetir = new Bunifu.Framework.UI.BunifuThinButton2();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.btnGeri = new Bunifu.Framework.UI.BunifuThinButton2();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(1074, 25);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(165, 25);
            this.label2.TabIndex = 1;
            this.label2.Text = "Sınav ID Giriniz:";
            // 
            // txtSinavID
            // 
            this.txtSinavID.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtSinavID.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtSinavID.characterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtSinavID.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtSinavID.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.txtSinavID.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtSinavID.HintForeColor = System.Drawing.Color.Empty;
            this.txtSinavID.HintText = "";
            this.txtSinavID.isPassword = false;
            this.txtSinavID.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtSinavID.LineIdleColor = System.Drawing.Color.Gray;
            this.txtSinavID.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtSinavID.LineThickness = 3;
            this.txtSinavID.Location = new System.Drawing.Point(1079, 71);
            this.txtSinavID.Margin = new System.Windows.Forms.Padding(4);
            this.txtSinavID.MaxLength = 32767;
            this.txtSinavID.Name = "txtSinavID";
            this.txtSinavID.Size = new System.Drawing.Size(160, 53);
            this.txtSinavID.TabIndex = 3;
            this.txtSinavID.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(43, 25);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 82;
            this.dataGridView1.RowTemplate.Height = 33;
            this.dataGridView1.Size = new System.Drawing.Size(1010, 282);
            this.dataGridView1.TabIndex = 4;
            // 
            // btnCvpGetir
            // 
            this.btnCvpGetir.ActiveBorderThickness = 1;
            this.btnCvpGetir.ActiveCornerRadius = 20;
            this.btnCvpGetir.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.btnCvpGetir.ActiveForecolor = System.Drawing.Color.White;
            this.btnCvpGetir.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.btnCvpGetir.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btnCvpGetir.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnCvpGetir.BackgroundImage")));
            this.btnCvpGetir.ButtonText = "Cevapları Getir";
            this.btnCvpGetir.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCvpGetir.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCvpGetir.ForeColor = System.Drawing.Color.SeaGreen;
            this.btnCvpGetir.IdleBorderThickness = 1;
            this.btnCvpGetir.IdleCornerRadius = 20;
            this.btnCvpGetir.IdleFillColor = System.Drawing.Color.White;
            this.btnCvpGetir.IdleForecolor = System.Drawing.Color.SeaGreen;
            this.btnCvpGetir.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.btnCvpGetir.Location = new System.Drawing.Point(1079, 168);
            this.btnCvpGetir.Margin = new System.Windows.Forms.Padding(5);
            this.btnCvpGetir.Name = "btnCvpGetir";
            this.btnCvpGetir.Size = new System.Drawing.Size(160, 139);
            this.btnCvpGetir.TabIndex = 5;
            this.btnCvpGetir.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnCvpGetir.Click += new System.EventHandler(this.btnCvpGetir_Click);
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(43, 332);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowHeadersWidth = 82;
            this.dataGridView2.RowTemplate.Height = 33;
            this.dataGridView2.Size = new System.Drawing.Size(1230, 295);
            this.dataGridView2.TabIndex = 6;
            // 
            // btnGeri
            // 
            this.btnGeri.ActiveBorderThickness = 1;
            this.btnGeri.ActiveCornerRadius = 20;
            this.btnGeri.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.btnGeri.ActiveForecolor = System.Drawing.Color.White;
            this.btnGeri.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.btnGeri.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btnGeri.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnGeri.BackgroundImage")));
            this.btnGeri.ButtonText = "GERİ DÖN";
            this.btnGeri.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnGeri.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGeri.ForeColor = System.Drawing.Color.SeaGreen;
            this.btnGeri.IdleBorderThickness = 1;
            this.btnGeri.IdleCornerRadius = 20;
            this.btnGeri.IdleFillColor = System.Drawing.Color.White;
            this.btnGeri.IdleForecolor = System.Drawing.Color.SeaGreen;
            this.btnGeri.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.btnGeri.Location = new System.Drawing.Point(518, 650);
            this.btnGeri.Margin = new System.Windows.Forms.Padding(5);
            this.btnGeri.Name = "btnGeri";
            this.btnGeri.Size = new System.Drawing.Size(297, 135);
            this.btnGeri.TabIndex = 7;
            this.btnGeri.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnGeri.Click += new System.EventHandler(this.btnGeri_Click);
            // 
            // FrmSonuc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.ClientSize = new System.Drawing.Size(1310, 814);
            this.Controls.Add(this.btnGeri);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.btnCvpGetir);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.txtSinavID);
            this.Controls.Add(this.label2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FrmSonuc";
            this.Text = "FrmSonuc";
            this.Load += new System.EventHandler(this.FrmSonuc_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label2;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtSinavID;
        private System.Windows.Forms.DataGridView dataGridView1;
        private Bunifu.Framework.UI.BunifuThinButton2 btnCvpGetir;
        private System.Windows.Forms.DataGridView dataGridView2;
        private Bunifu.Framework.UI.BunifuThinButton2 btnGeri;
    }
}