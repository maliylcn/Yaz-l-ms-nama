﻿namespace WindowsFormsApp2
{
    partial class FormSinavOlustur
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormSinavOlustur));
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.idDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.questionsDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cevap1DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cevap2DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cevap3DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cevap4DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sonucDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.subjectsidDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sorularBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.examDataSet2 = new WindowsFormsApp2.examDataSet2();
            this.sorularTableAdapter = new WindowsFormsApp2.examDataSet2TableAdapters.sorularTableAdapter();
            this.bunifuCustomLabel2 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel3 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel4 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel5 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel6 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel7 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel8 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel9 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel10 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel11 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.txtSoru10 = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.txtSoru9 = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.txtSoru8 = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.txtSoru7 = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.txtSoru6 = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.txtSoru5 = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.txtSoru4 = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.txtSoru3 = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.txtSoru2 = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.txtSoru1 = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.btnEkle = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btnGeri = new Bunifu.Framework.UI.BunifuThinButton2();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sorularBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.examDataSet2)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn,
            this.questionsDataGridViewTextBoxColumn,
            this.cevap1DataGridViewTextBoxColumn,
            this.cevap2DataGridViewTextBoxColumn,
            this.cevap3DataGridViewTextBoxColumn,
            this.cevap4DataGridViewTextBoxColumn,
            this.sonucDataGridViewTextBoxColumn,
            this.subjectsidDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.sorularBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(5, 0);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 82;
            this.dataGridView1.RowTemplate.Height = 33;
            this.dataGridView1.Size = new System.Drawing.Size(1486, 528);
            this.dataGridView1.TabIndex = 0;
            // 
            // idDataGridViewTextBoxColumn
            // 
            this.idDataGridViewTextBoxColumn.DataPropertyName = "id";
            this.idDataGridViewTextBoxColumn.HeaderText = "id";
            this.idDataGridViewTextBoxColumn.MinimumWidth = 10;
            this.idDataGridViewTextBoxColumn.Name = "idDataGridViewTextBoxColumn";
            this.idDataGridViewTextBoxColumn.Width = 200;
            // 
            // questionsDataGridViewTextBoxColumn
            // 
            this.questionsDataGridViewTextBoxColumn.DataPropertyName = "questions";
            this.questionsDataGridViewTextBoxColumn.HeaderText = "questions";
            this.questionsDataGridViewTextBoxColumn.MinimumWidth = 10;
            this.questionsDataGridViewTextBoxColumn.Name = "questionsDataGridViewTextBoxColumn";
            this.questionsDataGridViewTextBoxColumn.Width = 200;
            // 
            // cevap1DataGridViewTextBoxColumn
            // 
            this.cevap1DataGridViewTextBoxColumn.DataPropertyName = "cevap1";
            this.cevap1DataGridViewTextBoxColumn.HeaderText = "cevap1";
            this.cevap1DataGridViewTextBoxColumn.MinimumWidth = 10;
            this.cevap1DataGridViewTextBoxColumn.Name = "cevap1DataGridViewTextBoxColumn";
            this.cevap1DataGridViewTextBoxColumn.Width = 200;
            // 
            // cevap2DataGridViewTextBoxColumn
            // 
            this.cevap2DataGridViewTextBoxColumn.DataPropertyName = "cevap2";
            this.cevap2DataGridViewTextBoxColumn.HeaderText = "cevap2";
            this.cevap2DataGridViewTextBoxColumn.MinimumWidth = 10;
            this.cevap2DataGridViewTextBoxColumn.Name = "cevap2DataGridViewTextBoxColumn";
            this.cevap2DataGridViewTextBoxColumn.Width = 200;
            // 
            // cevap3DataGridViewTextBoxColumn
            // 
            this.cevap3DataGridViewTextBoxColumn.DataPropertyName = "cevap3";
            this.cevap3DataGridViewTextBoxColumn.HeaderText = "cevap3";
            this.cevap3DataGridViewTextBoxColumn.MinimumWidth = 10;
            this.cevap3DataGridViewTextBoxColumn.Name = "cevap3DataGridViewTextBoxColumn";
            this.cevap3DataGridViewTextBoxColumn.Width = 200;
            // 
            // cevap4DataGridViewTextBoxColumn
            // 
            this.cevap4DataGridViewTextBoxColumn.DataPropertyName = "cevap4";
            this.cevap4DataGridViewTextBoxColumn.HeaderText = "cevap4";
            this.cevap4DataGridViewTextBoxColumn.MinimumWidth = 10;
            this.cevap4DataGridViewTextBoxColumn.Name = "cevap4DataGridViewTextBoxColumn";
            this.cevap4DataGridViewTextBoxColumn.Width = 200;
            // 
            // sonucDataGridViewTextBoxColumn
            // 
            this.sonucDataGridViewTextBoxColumn.DataPropertyName = "sonuc";
            this.sonucDataGridViewTextBoxColumn.HeaderText = "sonuc";
            this.sonucDataGridViewTextBoxColumn.MinimumWidth = 10;
            this.sonucDataGridViewTextBoxColumn.Name = "sonucDataGridViewTextBoxColumn";
            this.sonucDataGridViewTextBoxColumn.Width = 200;
            // 
            // subjectsidDataGridViewTextBoxColumn
            // 
            this.subjectsidDataGridViewTextBoxColumn.DataPropertyName = "subjects_id";
            this.subjectsidDataGridViewTextBoxColumn.HeaderText = "subjects_id";
            this.subjectsidDataGridViewTextBoxColumn.MinimumWidth = 10;
            this.subjectsidDataGridViewTextBoxColumn.Name = "subjectsidDataGridViewTextBoxColumn";
            this.subjectsidDataGridViewTextBoxColumn.Width = 200;
            // 
            // sorularBindingSource
            // 
            this.sorularBindingSource.DataMember = "sorular";
            this.sorularBindingSource.DataSource = this.examDataSet2;
            // 
            // examDataSet2
            // 
            this.examDataSet2.DataSetName = "examDataSet2";
            this.examDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // sorularTableAdapter
            // 
            this.sorularTableAdapter.ClearBeforeFill = true;
            // 
            // bunifuCustomLabel2
            // 
            this.bunifuCustomLabel2.AutoSize = true;
            this.bunifuCustomLabel2.Location = new System.Drawing.Point(636, 834);
            this.bunifuCustomLabel2.Name = "bunifuCustomLabel2";
            this.bunifuCustomLabel2.Size = new System.Drawing.Size(134, 25);
            this.bunifuCustomLabel2.TabIndex = 2;
            this.bunifuCustomLabel2.Text = "SORU 10 İD:";
            // 
            // bunifuCustomLabel3
            // 
            this.bunifuCustomLabel3.AutoSize = true;
            this.bunifuCustomLabel3.Location = new System.Drawing.Point(636, 775);
            this.bunifuCustomLabel3.Name = "bunifuCustomLabel3";
            this.bunifuCustomLabel3.Size = new System.Drawing.Size(122, 25);
            this.bunifuCustomLabel3.TabIndex = 3;
            this.bunifuCustomLabel3.Text = "SORU 9 İD:";
            // 
            // bunifuCustomLabel4
            // 
            this.bunifuCustomLabel4.AutoSize = true;
            this.bunifuCustomLabel4.Location = new System.Drawing.Point(636, 706);
            this.bunifuCustomLabel4.Name = "bunifuCustomLabel4";
            this.bunifuCustomLabel4.Size = new System.Drawing.Size(122, 25);
            this.bunifuCustomLabel4.TabIndex = 4;
            this.bunifuCustomLabel4.Text = "SORU 8 İD:";
            // 
            // bunifuCustomLabel5
            // 
            this.bunifuCustomLabel5.AutoSize = true;
            this.bunifuCustomLabel5.Location = new System.Drawing.Point(636, 642);
            this.bunifuCustomLabel5.Name = "bunifuCustomLabel5";
            this.bunifuCustomLabel5.Size = new System.Drawing.Size(122, 25);
            this.bunifuCustomLabel5.TabIndex = 5;
            this.bunifuCustomLabel5.Text = "SORU 7 İD:";
            // 
            // bunifuCustomLabel6
            // 
            this.bunifuCustomLabel6.AutoSize = true;
            this.bunifuCustomLabel6.Location = new System.Drawing.Point(636, 568);
            this.bunifuCustomLabel6.Name = "bunifuCustomLabel6";
            this.bunifuCustomLabel6.Size = new System.Drawing.Size(122, 25);
            this.bunifuCustomLabel6.TabIndex = 6;
            this.bunifuCustomLabel6.Text = "SORU 6 İD:";
            // 
            // bunifuCustomLabel7
            // 
            this.bunifuCustomLabel7.AutoSize = true;
            this.bunifuCustomLabel7.Location = new System.Drawing.Point(24, 834);
            this.bunifuCustomLabel7.Name = "bunifuCustomLabel7";
            this.bunifuCustomLabel7.Size = new System.Drawing.Size(122, 25);
            this.bunifuCustomLabel7.TabIndex = 7;
            this.bunifuCustomLabel7.Text = "SORU 5 İD:";
            // 
            // bunifuCustomLabel8
            // 
            this.bunifuCustomLabel8.AutoSize = true;
            this.bunifuCustomLabel8.Location = new System.Drawing.Point(24, 764);
            this.bunifuCustomLabel8.Name = "bunifuCustomLabel8";
            this.bunifuCustomLabel8.Size = new System.Drawing.Size(122, 25);
            this.bunifuCustomLabel8.TabIndex = 8;
            this.bunifuCustomLabel8.Text = "SORU 4 İD:";
            // 
            // bunifuCustomLabel9
            // 
            this.bunifuCustomLabel9.AutoSize = true;
            this.bunifuCustomLabel9.Location = new System.Drawing.Point(24, 706);
            this.bunifuCustomLabel9.Name = "bunifuCustomLabel9";
            this.bunifuCustomLabel9.Size = new System.Drawing.Size(122, 25);
            this.bunifuCustomLabel9.TabIndex = 9;
            this.bunifuCustomLabel9.Text = "SORU 3 İD:";
            // 
            // bunifuCustomLabel10
            // 
            this.bunifuCustomLabel10.AutoSize = true;
            this.bunifuCustomLabel10.Location = new System.Drawing.Point(24, 642);
            this.bunifuCustomLabel10.Name = "bunifuCustomLabel10";
            this.bunifuCustomLabel10.Size = new System.Drawing.Size(122, 25);
            this.bunifuCustomLabel10.TabIndex = 10;
            this.bunifuCustomLabel10.Text = "SORU 2 İD:";
            // 
            // bunifuCustomLabel11
            // 
            this.bunifuCustomLabel11.AutoSize = true;
            this.bunifuCustomLabel11.Location = new System.Drawing.Point(24, 568);
            this.bunifuCustomLabel11.Name = "bunifuCustomLabel11";
            this.bunifuCustomLabel11.Size = new System.Drawing.Size(122, 25);
            this.bunifuCustomLabel11.TabIndex = 11;
            this.bunifuCustomLabel11.Text = "SORU 1 İD:";
            // 
            // txtSoru10
            // 
            this.txtSoru10.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtSoru10.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtSoru10.characterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtSoru10.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtSoru10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.txtSoru10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtSoru10.HintForeColor = System.Drawing.Color.Empty;
            this.txtSoru10.HintText = "";
            this.txtSoru10.isPassword = false;
            this.txtSoru10.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtSoru10.LineIdleColor = System.Drawing.Color.Gray;
            this.txtSoru10.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtSoru10.LineThickness = 3;
            this.txtSoru10.Location = new System.Drawing.Point(804, 810);
            this.txtSoru10.Margin = new System.Windows.Forms.Padding(4);
            this.txtSoru10.MaxLength = 32767;
            this.txtSoru10.Name = "txtSoru10";
            this.txtSoru10.Size = new System.Drawing.Size(379, 49);
            this.txtSoru10.TabIndex = 12;
            this.txtSoru10.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // txtSoru9
            // 
            this.txtSoru9.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtSoru9.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtSoru9.characterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtSoru9.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtSoru9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.txtSoru9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtSoru9.HintForeColor = System.Drawing.Color.Empty;
            this.txtSoru9.HintText = "";
            this.txtSoru9.isPassword = false;
            this.txtSoru9.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtSoru9.LineIdleColor = System.Drawing.Color.Gray;
            this.txtSoru9.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtSoru9.LineThickness = 3;
            this.txtSoru9.Location = new System.Drawing.Point(804, 751);
            this.txtSoru9.Margin = new System.Windows.Forms.Padding(4);
            this.txtSoru9.MaxLength = 32767;
            this.txtSoru9.Name = "txtSoru9";
            this.txtSoru9.Size = new System.Drawing.Size(379, 49);
            this.txtSoru9.TabIndex = 13;
            this.txtSoru9.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // txtSoru8
            // 
            this.txtSoru8.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtSoru8.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtSoru8.characterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtSoru8.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtSoru8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.txtSoru8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtSoru8.HintForeColor = System.Drawing.Color.Empty;
            this.txtSoru8.HintText = "";
            this.txtSoru8.isPassword = false;
            this.txtSoru8.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtSoru8.LineIdleColor = System.Drawing.Color.Gray;
            this.txtSoru8.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtSoru8.LineThickness = 3;
            this.txtSoru8.Location = new System.Drawing.Point(804, 688);
            this.txtSoru8.Margin = new System.Windows.Forms.Padding(4);
            this.txtSoru8.MaxLength = 32767;
            this.txtSoru8.Name = "txtSoru8";
            this.txtSoru8.Size = new System.Drawing.Size(379, 43);
            this.txtSoru8.TabIndex = 14;
            this.txtSoru8.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // txtSoru7
            // 
            this.txtSoru7.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtSoru7.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtSoru7.characterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtSoru7.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtSoru7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.txtSoru7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtSoru7.HintForeColor = System.Drawing.Color.Empty;
            this.txtSoru7.HintText = "";
            this.txtSoru7.isPassword = false;
            this.txtSoru7.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtSoru7.LineIdleColor = System.Drawing.Color.Gray;
            this.txtSoru7.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtSoru7.LineThickness = 3;
            this.txtSoru7.Location = new System.Drawing.Point(804, 618);
            this.txtSoru7.Margin = new System.Windows.Forms.Padding(4);
            this.txtSoru7.MaxLength = 32767;
            this.txtSoru7.Name = "txtSoru7";
            this.txtSoru7.Size = new System.Drawing.Size(379, 49);
            this.txtSoru7.TabIndex = 15;
            this.txtSoru7.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // txtSoru6
            // 
            this.txtSoru6.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtSoru6.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtSoru6.characterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtSoru6.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtSoru6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.txtSoru6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtSoru6.HintForeColor = System.Drawing.Color.Empty;
            this.txtSoru6.HintText = "";
            this.txtSoru6.isPassword = false;
            this.txtSoru6.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtSoru6.LineIdleColor = System.Drawing.Color.Gray;
            this.txtSoru6.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtSoru6.LineThickness = 3;
            this.txtSoru6.Location = new System.Drawing.Point(804, 548);
            this.txtSoru6.Margin = new System.Windows.Forms.Padding(4);
            this.txtSoru6.MaxLength = 32767;
            this.txtSoru6.Name = "txtSoru6";
            this.txtSoru6.Size = new System.Drawing.Size(379, 45);
            this.txtSoru6.TabIndex = 16;
            this.txtSoru6.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // txtSoru5
            // 
            this.txtSoru5.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtSoru5.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtSoru5.characterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtSoru5.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtSoru5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.txtSoru5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtSoru5.HintForeColor = System.Drawing.Color.Empty;
            this.txtSoru5.HintText = "";
            this.txtSoru5.isPassword = false;
            this.txtSoru5.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtSoru5.LineIdleColor = System.Drawing.Color.Gray;
            this.txtSoru5.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtSoru5.LineThickness = 3;
            this.txtSoru5.Location = new System.Drawing.Point(194, 810);
            this.txtSoru5.Margin = new System.Windows.Forms.Padding(4);
            this.txtSoru5.MaxLength = 32767;
            this.txtSoru5.Name = "txtSoru5";
            this.txtSoru5.Size = new System.Drawing.Size(379, 49);
            this.txtSoru5.TabIndex = 17;
            this.txtSoru5.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // txtSoru4
            // 
            this.txtSoru4.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtSoru4.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtSoru4.characterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtSoru4.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtSoru4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.txtSoru4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtSoru4.HintForeColor = System.Drawing.Color.Empty;
            this.txtSoru4.HintText = "";
            this.txtSoru4.isPassword = false;
            this.txtSoru4.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtSoru4.LineIdleColor = System.Drawing.Color.Gray;
            this.txtSoru4.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtSoru4.LineThickness = 3;
            this.txtSoru4.Location = new System.Drawing.Point(194, 751);
            this.txtSoru4.Margin = new System.Windows.Forms.Padding(4);
            this.txtSoru4.MaxLength = 32767;
            this.txtSoru4.Name = "txtSoru4";
            this.txtSoru4.Size = new System.Drawing.Size(379, 38);
            this.txtSoru4.TabIndex = 18;
            this.txtSoru4.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // txtSoru3
            // 
            this.txtSoru3.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtSoru3.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtSoru3.characterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtSoru3.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtSoru3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.txtSoru3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtSoru3.HintForeColor = System.Drawing.Color.Empty;
            this.txtSoru3.HintText = "";
            this.txtSoru3.isPassword = false;
            this.txtSoru3.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtSoru3.LineIdleColor = System.Drawing.Color.Gray;
            this.txtSoru3.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtSoru3.LineThickness = 3;
            this.txtSoru3.Location = new System.Drawing.Point(194, 688);
            this.txtSoru3.Margin = new System.Windows.Forms.Padding(4);
            this.txtSoru3.MaxLength = 32767;
            this.txtSoru3.Name = "txtSoru3";
            this.txtSoru3.Size = new System.Drawing.Size(379, 43);
            this.txtSoru3.TabIndex = 19;
            this.txtSoru3.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // txtSoru2
            // 
            this.txtSoru2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtSoru2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtSoru2.characterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtSoru2.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtSoru2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.txtSoru2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtSoru2.HintForeColor = System.Drawing.Color.Empty;
            this.txtSoru2.HintText = "";
            this.txtSoru2.isPassword = false;
            this.txtSoru2.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtSoru2.LineIdleColor = System.Drawing.Color.Gray;
            this.txtSoru2.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtSoru2.LineThickness = 3;
            this.txtSoru2.Location = new System.Drawing.Point(194, 618);
            this.txtSoru2.Margin = new System.Windows.Forms.Padding(4);
            this.txtSoru2.MaxLength = 32767;
            this.txtSoru2.Name = "txtSoru2";
            this.txtSoru2.Size = new System.Drawing.Size(379, 49);
            this.txtSoru2.TabIndex = 20;
            this.txtSoru2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // txtSoru1
            // 
            this.txtSoru1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtSoru1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtSoru1.characterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtSoru1.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtSoru1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.txtSoru1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtSoru1.HintForeColor = System.Drawing.Color.Empty;
            this.txtSoru1.HintText = "";
            this.txtSoru1.isPassword = false;
            this.txtSoru1.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtSoru1.LineIdleColor = System.Drawing.Color.Gray;
            this.txtSoru1.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtSoru1.LineThickness = 3;
            this.txtSoru1.Location = new System.Drawing.Point(194, 546);
            this.txtSoru1.Margin = new System.Windows.Forms.Padding(4);
            this.txtSoru1.MaxLength = 32767;
            this.txtSoru1.Name = "txtSoru1";
            this.txtSoru1.Size = new System.Drawing.Size(379, 47);
            this.txtSoru1.TabIndex = 21;
            this.txtSoru1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // btnEkle
            // 
            this.btnEkle.ActiveBorderThickness = 1;
            this.btnEkle.ActiveCornerRadius = 20;
            this.btnEkle.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.btnEkle.ActiveForecolor = System.Drawing.Color.White;
            this.btnEkle.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.btnEkle.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btnEkle.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnEkle.BackgroundImage")));
            this.btnEkle.ButtonText = "OLUŞTUR";
            this.btnEkle.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnEkle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEkle.ForeColor = System.Drawing.Color.SeaGreen;
            this.btnEkle.IdleBorderThickness = 1;
            this.btnEkle.IdleCornerRadius = 20;
            this.btnEkle.IdleFillColor = System.Drawing.Color.White;
            this.btnEkle.IdleForecolor = System.Drawing.Color.SeaGreen;
            this.btnEkle.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.btnEkle.Location = new System.Drawing.Point(1258, 546);
            this.btnEkle.Margin = new System.Windows.Forms.Padding(5);
            this.btnEkle.Name = "btnEkle";
            this.btnEkle.Size = new System.Drawing.Size(181, 163);
            this.btnEkle.TabIndex = 22;
            this.btnEkle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnEkle.Click += new System.EventHandler(this.btnEkle_Click);
            // 
            // btnGeri
            // 
            this.btnGeri.ActiveBorderThickness = 1;
            this.btnGeri.ActiveCornerRadius = 20;
            this.btnGeri.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.btnGeri.ActiveForecolor = System.Drawing.Color.White;
            this.btnGeri.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.btnGeri.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btnGeri.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnGeri.BackgroundImage")));
            this.btnGeri.ButtonText = "GERİ DÖN";
            this.btnGeri.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnGeri.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGeri.ForeColor = System.Drawing.Color.SeaGreen;
            this.btnGeri.IdleBorderThickness = 1;
            this.btnGeri.IdleCornerRadius = 20;
            this.btnGeri.IdleFillColor = System.Drawing.Color.White;
            this.btnGeri.IdleForecolor = System.Drawing.Color.SeaGreen;
            this.btnGeri.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.btnGeri.Location = new System.Drawing.Point(1258, 719);
            this.btnGeri.Margin = new System.Windows.Forms.Padding(5);
            this.btnGeri.Name = "btnGeri";
            this.btnGeri.Size = new System.Drawing.Size(181, 161);
            this.btnGeri.TabIndex = 23;
            this.btnGeri.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnGeri.Click += new System.EventHandler(this.btnGeri_Click);
            // 
            // FormSinavOlustur
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.ClientSize = new System.Drawing.Size(1486, 942);
            this.Controls.Add(this.btnGeri);
            this.Controls.Add(this.btnEkle);
            this.Controls.Add(this.txtSoru1);
            this.Controls.Add(this.txtSoru2);
            this.Controls.Add(this.txtSoru3);
            this.Controls.Add(this.txtSoru4);
            this.Controls.Add(this.txtSoru5);
            this.Controls.Add(this.txtSoru6);
            this.Controls.Add(this.txtSoru7);
            this.Controls.Add(this.txtSoru8);
            this.Controls.Add(this.txtSoru9);
            this.Controls.Add(this.txtSoru10);
            this.Controls.Add(this.bunifuCustomLabel11);
            this.Controls.Add(this.bunifuCustomLabel10);
            this.Controls.Add(this.bunifuCustomLabel9);
            this.Controls.Add(this.bunifuCustomLabel8);
            this.Controls.Add(this.bunifuCustomLabel7);
            this.Controls.Add(this.bunifuCustomLabel6);
            this.Controls.Add(this.bunifuCustomLabel5);
            this.Controls.Add(this.bunifuCustomLabel4);
            this.Controls.Add(this.bunifuCustomLabel3);
            this.Controls.Add(this.bunifuCustomLabel2);
            this.Controls.Add(this.dataGridView1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FormSinavOlustur";
            this.Text = "FormSinavOlustur";
            this.Load += new System.EventHandler(this.FormSinavOlustur_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sorularBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.examDataSet2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private examDataSet2 examDataSet2;
        private System.Windows.Forms.BindingSource sorularBindingSource;
        private examDataSet2TableAdapters.sorularTableAdapter sorularTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn questionsDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cevap1DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cevap2DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cevap3DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cevap4DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sonucDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn subjectsidDataGridViewTextBoxColumn;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel2;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel3;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel4;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel5;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel6;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel7;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel8;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel9;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel10;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel11;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtSoru10;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtSoru9;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtSoru8;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtSoru7;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtSoru6;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtSoru5;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtSoru4;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtSoru3;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtSoru2;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtSoru1;
        private Bunifu.Framework.UI.BunifuThinButton2 btnEkle;
        private Bunifu.Framework.UI.BunifuThinButton2 btnGeri;
    }
}