﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data;
using MySql.Data.MySqlClient;
using windowsFormsApp1;

namespace WindowsFormsApp2
{
    public partial class FormOgrenci : Form
    {
        public MySqlConnection con = new MySqlConnection("Server=localhost;Database=exam;Uid=root;Pwd='';");

        int i;
        public FormOgrenci()
        {
            InitializeComponent();
        }

        private void btnOgrGiris_Click(object sender, EventArgs e)
        {
            i = 0;

            con.Open();
            MySqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select *  from kullanicilar where username='" + txtOgrAd.Text + "' and password = '" + txtOgrSifre.Text + "' and role = 'ogr'";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            da.Fill(dt);

            i = Convert.ToInt32(dt.Rows.Count.ToString());

            if (i == 0)
            {
                label3.Text = "YANLIŞ KULLANICI ADI VEYA ŞİFRE";
            }
            else
            {
                this.Hide();
                OgrenciSayfa fm = new OgrenciSayfa();
                fm.Show();
            }
            con.Close();
        }

        private void btnOgertmenCikis_Click(object sender, EventArgs e)
        {
            this.Close();
            Form1 fm = new Form1();
            fm.Show();
        }
    }
}
