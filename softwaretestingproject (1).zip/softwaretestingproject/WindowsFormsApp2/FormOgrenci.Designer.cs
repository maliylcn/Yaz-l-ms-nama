﻿namespace WindowsFormsApp2
{
    partial class FormOgrenci
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormOgrenci));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtOgrAd = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.txtOgrSifre = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.bunifuTileButton1 = new Bunifu.Framework.UI.BunifuTileButton();
            this.btnOgrGiris = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btnOgertmenCikis = new Bunifu.Framework.UI.BunifuThinButton2();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label1.Location = new System.Drawing.Point(423, 15);
            this.label1.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(280, 44);
            this.label1.TabIndex = 17;
            this.label1.Text = "ÖĞRENCİ AD:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label2.Location = new System.Drawing.Point(423, 126);
            this.label2.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(147, 44);
            this.label2.TabIndex = 18;
            this.label2.Text = "ŞİFRE:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.Location = new System.Drawing.Point(433, 363);
            this.label3.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(0, 29);
            this.label3.TabIndex = 19;
            // 
            // txtOgrAd
            // 
            this.txtOgrAd.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtOgrAd.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtOgrAd.characterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtOgrAd.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtOgrAd.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.txtOgrAd.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtOgrAd.HintForeColor = System.Drawing.Color.Empty;
            this.txtOgrAd.HintText = "";
            this.txtOgrAd.isPassword = false;
            this.txtOgrAd.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtOgrAd.LineIdleColor = System.Drawing.Color.Gray;
            this.txtOgrAd.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtOgrAd.LineThickness = 3;
            this.txtOgrAd.Location = new System.Drawing.Point(715, 15);
            this.txtOgrAd.Margin = new System.Windows.Forms.Padding(4);
            this.txtOgrAd.MaxLength = 32767;
            this.txtOgrAd.Name = "txtOgrAd";
            this.txtOgrAd.Size = new System.Drawing.Size(550, 56);
            this.txtOgrAd.TabIndex = 20;
            this.txtOgrAd.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // txtOgrSifre
            // 
            this.txtOgrSifre.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtOgrSifre.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtOgrSifre.characterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtOgrSifre.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtOgrSifre.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.txtOgrSifre.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtOgrSifre.HintForeColor = System.Drawing.Color.Empty;
            this.txtOgrSifre.HintText = "";
            this.txtOgrSifre.isPassword = true;
            this.txtOgrSifre.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtOgrSifre.LineIdleColor = System.Drawing.Color.Gray;
            this.txtOgrSifre.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtOgrSifre.LineThickness = 3;
            this.txtOgrSifre.Location = new System.Drawing.Point(715, 126);
            this.txtOgrSifre.Margin = new System.Windows.Forms.Padding(4);
            this.txtOgrSifre.MaxLength = 32767;
            this.txtOgrSifre.Name = "txtOgrSifre";
            this.txtOgrSifre.Size = new System.Drawing.Size(550, 66);
            this.txtOgrSifre.TabIndex = 21;
            this.txtOgrSifre.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // bunifuTileButton1
            // 
            this.bunifuTileButton1.BackColor = System.Drawing.Color.SeaGreen;
            this.bunifuTileButton1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.bunifuTileButton1.color = System.Drawing.Color.SeaGreen;
            this.bunifuTileButton1.colorActive = System.Drawing.Color.MediumSeaGreen;
            this.bunifuTileButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuTileButton1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F);
            this.bunifuTileButton1.ForeColor = System.Drawing.Color.White;
            this.bunifuTileButton1.Image = global::WindowsFormsApp2.Properties.Resources.kisspng_computer_icons_student_icon_design_students_5ac9c1061a3927_6329483215231715901074;
            this.bunifuTileButton1.ImagePosition = 20;
            this.bunifuTileButton1.ImageZoom = 50;
            this.bunifuTileButton1.LabelPosition = 80;
            this.bunifuTileButton1.LabelText = "ÖĞRENCİ GİRİŞİ";
            this.bunifuTileButton1.Location = new System.Drawing.Point(15, 15);
            this.bunifuTileButton1.Margin = new System.Windows.Forms.Padding(6);
            this.bunifuTileButton1.Name = "bunifuTileButton1";
            this.bunifuTileButton1.Size = new System.Drawing.Size(386, 365);
            this.bunifuTileButton1.TabIndex = 24;
            // 
            // btnOgrGiris
            // 
            this.btnOgrGiris.ActiveBorderThickness = 1;
            this.btnOgrGiris.ActiveCornerRadius = 20;
            this.btnOgrGiris.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.btnOgrGiris.ActiveForecolor = System.Drawing.Color.White;
            this.btnOgrGiris.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.btnOgrGiris.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btnOgrGiris.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnOgrGiris.BackgroundImage")));
            this.btnOgrGiris.ButtonText = "GİRİŞ YAP";
            this.btnOgrGiris.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnOgrGiris.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOgrGiris.ForeColor = System.Drawing.Color.SeaGreen;
            this.btnOgrGiris.IdleBorderThickness = 1;
            this.btnOgrGiris.IdleCornerRadius = 20;
            this.btnOgrGiris.IdleFillColor = System.Drawing.Color.White;
            this.btnOgrGiris.IdleForecolor = System.Drawing.Color.SeaGreen;
            this.btnOgrGiris.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.btnOgrGiris.Location = new System.Drawing.Point(847, 253);
            this.btnOgrGiris.Margin = new System.Windows.Forms.Padding(5);
            this.btnOgrGiris.Name = "btnOgrGiris";
            this.btnOgrGiris.Size = new System.Drawing.Size(418, 84);
            this.btnOgrGiris.TabIndex = 23;
            this.btnOgrGiris.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnOgrGiris.Click += new System.EventHandler(this.btnOgrGiris_Click);
            // 
            // btnOgertmenCikis
            // 
            this.btnOgertmenCikis.ActiveBorderThickness = 1;
            this.btnOgertmenCikis.ActiveCornerRadius = 20;
            this.btnOgertmenCikis.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.btnOgertmenCikis.ActiveForecolor = System.Drawing.Color.White;
            this.btnOgertmenCikis.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.btnOgertmenCikis.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btnOgertmenCikis.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnOgertmenCikis.BackgroundImage")));
            this.btnOgertmenCikis.ButtonText = "ÇIKIŞ";
            this.btnOgertmenCikis.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnOgertmenCikis.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOgertmenCikis.ForeColor = System.Drawing.Color.SeaGreen;
            this.btnOgertmenCikis.IdleBorderThickness = 1;
            this.btnOgertmenCikis.IdleCornerRadius = 20;
            this.btnOgertmenCikis.IdleFillColor = System.Drawing.Color.White;
            this.btnOgertmenCikis.IdleForecolor = System.Drawing.Color.SeaGreen;
            this.btnOgertmenCikis.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.btnOgertmenCikis.Location = new System.Drawing.Point(431, 253);
            this.btnOgertmenCikis.Margin = new System.Windows.Forms.Padding(5);
            this.btnOgertmenCikis.Name = "btnOgertmenCikis";
            this.btnOgertmenCikis.Size = new System.Drawing.Size(406, 84);
            this.btnOgertmenCikis.TabIndex = 22;
            this.btnOgertmenCikis.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnOgertmenCikis.Click += new System.EventHandler(this.btnOgertmenCikis_Click);
            // 
            // FormOgrenci
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.ClientSize = new System.Drawing.Size(1292, 398);
            this.ControlBox = false;
            this.Controls.Add(this.bunifuTileButton1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btnOgrGiris);
            this.Controls.Add(this.txtOgrAd);
            this.Controls.Add(this.btnOgertmenCikis);
            this.Controls.Add(this.txtOgrSifre);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FormOgrenci";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private Bunifu.Framework.UI.BunifuThinButton2 btnOgrGiris;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtOgrAd;
        private Bunifu.Framework.UI.BunifuThinButton2 btnOgertmenCikis;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtOgrSifre;
        private Bunifu.Framework.UI.BunifuTileButton bunifuTileButton1;
    }
}