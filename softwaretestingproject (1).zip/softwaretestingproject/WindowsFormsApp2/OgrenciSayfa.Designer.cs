﻿namespace WindowsFormsApp2
{
    partial class OgrenciSayfa
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(OgrenciSayfa));
            this.btnSonuc = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btnSınav = new Bunifu.Framework.UI.BunifuThinButton2();
            this.bunifuCustomLabel1 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.btnGeri = new Bunifu.Framework.UI.BunifuThinButton2();
            this.SuspendLayout();
            // 
            // btnSonuc
            // 
            this.btnSonuc.ActiveBorderThickness = 1;
            this.btnSonuc.ActiveCornerRadius = 20;
            this.btnSonuc.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.btnSonuc.ActiveForecolor = System.Drawing.Color.White;
            this.btnSonuc.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.btnSonuc.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btnSonuc.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSonuc.BackgroundImage")));
            this.btnSonuc.ButtonText = "SONUÇLAR";
            this.btnSonuc.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSonuc.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSonuc.ForeColor = System.Drawing.Color.SeaGreen;
            this.btnSonuc.IdleBorderThickness = 1;
            this.btnSonuc.IdleCornerRadius = 20;
            this.btnSonuc.IdleFillColor = System.Drawing.Color.White;
            this.btnSonuc.IdleForecolor = System.Drawing.Color.SeaGreen;
            this.btnSonuc.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.btnSonuc.Location = new System.Drawing.Point(35, 342);
            this.btnSonuc.Margin = new System.Windows.Forms.Padding(5);
            this.btnSonuc.Name = "btnSonuc";
            this.btnSonuc.Size = new System.Drawing.Size(653, 124);
            this.btnSonuc.TabIndex = 1;
            this.btnSonuc.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnSonuc.Click += new System.EventHandler(this.btnSonuc_Click);
            // 
            // btnSınav
            // 
            this.btnSınav.ActiveBorderThickness = 1;
            this.btnSınav.ActiveCornerRadius = 20;
            this.btnSınav.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.btnSınav.ActiveForecolor = System.Drawing.Color.White;
            this.btnSınav.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.btnSınav.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btnSınav.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSınav.BackgroundImage")));
            this.btnSınav.ButtonText = "SINAVA GİR";
            this.btnSınav.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSınav.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSınav.ForeColor = System.Drawing.Color.SeaGreen;
            this.btnSınav.IdleBorderThickness = 1;
            this.btnSınav.IdleCornerRadius = 20;
            this.btnSınav.IdleFillColor = System.Drawing.Color.White;
            this.btnSınav.IdleForecolor = System.Drawing.Color.SeaGreen;
            this.btnSınav.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.btnSınav.Location = new System.Drawing.Point(35, 202);
            this.btnSınav.Margin = new System.Windows.Forms.Padding(5);
            this.btnSınav.Name = "btnSınav";
            this.btnSınav.Size = new System.Drawing.Size(653, 130);
            this.btnSınav.TabIndex = 2;
            this.btnSınav.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnSınav.Click += new System.EventHandler(this.btnSınav_Click);
            // 
            // bunifuCustomLabel1
            // 
            this.bunifuCustomLabel1.AutoSize = true;
            this.bunifuCustomLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel1.Location = new System.Drawing.Point(28, 9);
            this.bunifuCustomLabel1.Name = "bunifuCustomLabel1";
            this.bunifuCustomLabel1.Size = new System.Drawing.Size(660, 148);
            this.bunifuCustomLabel1.TabIndex = 3;
            this.bunifuCustomLabel1.Text = "                    HOŞ GELDİNİZ\r\n\r\nBu ekrandan sınava girebilir ya da geçmiş \r\nt" +
    "arihli sınav sonuçlarınızı görebilirsiniz...";
            // 
            // btnGeri
            // 
            this.btnGeri.ActiveBorderThickness = 1;
            this.btnGeri.ActiveCornerRadius = 20;
            this.btnGeri.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.btnGeri.ActiveForecolor = System.Drawing.Color.White;
            this.btnGeri.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.btnGeri.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btnGeri.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnGeri.BackgroundImage")));
            this.btnGeri.ButtonText = "GERİ DÖN";
            this.btnGeri.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnGeri.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGeri.ForeColor = System.Drawing.Color.SeaGreen;
            this.btnGeri.IdleBorderThickness = 1;
            this.btnGeri.IdleCornerRadius = 20;
            this.btnGeri.IdleFillColor = System.Drawing.Color.White;
            this.btnGeri.IdleForecolor = System.Drawing.Color.SeaGreen;
            this.btnGeri.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.btnGeri.Location = new System.Drawing.Point(35, 476);
            this.btnGeri.Margin = new System.Windows.Forms.Padding(5);
            this.btnGeri.Name = "btnGeri";
            this.btnGeri.Size = new System.Drawing.Size(653, 118);
            this.btnGeri.TabIndex = 4;
            this.btnGeri.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnGeri.Click += new System.EventHandler(this.btnGeri_Click);
            // 
            // OgrenciSayfa
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.ClientSize = new System.Drawing.Size(726, 632);
            this.Controls.Add(this.btnGeri);
            this.Controls.Add(this.bunifuCustomLabel1);
            this.Controls.Add(this.btnSınav);
            this.Controls.Add(this.btnSonuc);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "OgrenciSayfa";
            this.Text = "OgrenciSayfa";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Bunifu.Framework.UI.BunifuThinButton2 btnSonuc;
        private Bunifu.Framework.UI.BunifuThinButton2 btnSınav;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel1;
        private Bunifu.Framework.UI.BunifuThinButton2 btnGeri;
    }
}