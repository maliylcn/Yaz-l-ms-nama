﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class FrmSınav : Form
    {
        public FrmSınav()
        {
            InitializeComponent();
        }

        private void btnBasla_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormSoru fm = new FormSoru();
            fm.Show();
        }

        private void btnGeri_Click(object sender, EventArgs e)
        {
            this.Close();
            OgrenciSayfa fm = new OgrenciSayfa();
            fm.Show();
        }
    }
}
