﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WwindowsFormsApp1;
using WindowsFormsApp2;

namespace windowsFormsApp1
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }


        private void btnSoruEkle_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form5 fm = new Form5();
            fm.Show();
        }

        private void btnSoruCıkar_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormSoruCikar fm = new FormSoruCikar();
            fm.Show();
        }

        private void btnSinavOlustur_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormSinavOlustur fm = new FormSinavOlustur();
            fm.Show();
        }

        private void btnGeri_Click(object sender, EventArgs e)
        {
            this.Close();
            Form1 fm = new Form1();
            fm.Show();
        }
    }
}
