﻿namespace WindowsFormsApp2
{
    partial class FrmSınav
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmSınav));
            this.bunifuCustomLabel1 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel2 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.btnBasla = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btnGeri = new Bunifu.Framework.UI.BunifuThinButton2();
            this.SuspendLayout();
            // 
            // bunifuCustomLabel1
            // 
            this.bunifuCustomLabel1.AutoSize = true;
            this.bunifuCustomLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel1.Location = new System.Drawing.Point(248, 362);
            this.bunifuCustomLabel1.Name = "bunifuCustomLabel1";
            this.bunifuCustomLabel1.Size = new System.Drawing.Size(565, 37);
            this.bunifuCustomLabel1.TabIndex = 0;
            this.bunifuCustomLabel1.Text = "Sınava Başlamak İçin Butona Basın ";
            // 
            // bunifuCustomLabel2
            // 
            this.bunifuCustomLabel2.AutoSize = true;
            this.bunifuCustomLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel2.Location = new System.Drawing.Point(114, 30);
            this.bunifuCustomLabel2.Name = "bunifuCustomLabel2";
            this.bunifuCustomLabel2.Size = new System.Drawing.Size(837, 259);
            this.bunifuCustomLabel2.TabIndex = 1;
            this.bunifuCustomLabel2.Text = resources.GetString("bunifuCustomLabel2.Text");
            // 
            // btnBasla
            // 
            this.btnBasla.ActiveBorderThickness = 1;
            this.btnBasla.ActiveCornerRadius = 20;
            this.btnBasla.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.btnBasla.ActiveForecolor = System.Drawing.Color.White;
            this.btnBasla.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.btnBasla.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btnBasla.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnBasla.BackgroundImage")));
            this.btnBasla.ButtonText = "BAŞLA";
            this.btnBasla.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnBasla.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBasla.ForeColor = System.Drawing.Color.SeaGreen;
            this.btnBasla.IdleBorderThickness = 1;
            this.btnBasla.IdleCornerRadius = 20;
            this.btnBasla.IdleFillColor = System.Drawing.Color.White;
            this.btnBasla.IdleForecolor = System.Drawing.Color.SeaGreen;
            this.btnBasla.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.btnBasla.Location = new System.Drawing.Point(361, 448);
            this.btnBasla.Margin = new System.Windows.Forms.Padding(5);
            this.btnBasla.Name = "btnBasla";
            this.btnBasla.Size = new System.Drawing.Size(304, 117);
            this.btnBasla.TabIndex = 2;
            this.btnBasla.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnBasla.Click += new System.EventHandler(this.btnBasla_Click);
            // 
            // btnGeri
            // 
            this.btnGeri.ActiveBorderThickness = 1;
            this.btnGeri.ActiveCornerRadius = 20;
            this.btnGeri.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.btnGeri.ActiveForecolor = System.Drawing.Color.White;
            this.btnGeri.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.btnGeri.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btnGeri.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnGeri.BackgroundImage")));
            this.btnGeri.ButtonText = "GERİ DÖN";
            this.btnGeri.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnGeri.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGeri.ForeColor = System.Drawing.Color.SeaGreen;
            this.btnGeri.IdleBorderThickness = 1;
            this.btnGeri.IdleCornerRadius = 20;
            this.btnGeri.IdleFillColor = System.Drawing.Color.White;
            this.btnGeri.IdleForecolor = System.Drawing.Color.SeaGreen;
            this.btnGeri.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.btnGeri.Location = new System.Drawing.Point(361, 575);
            this.btnGeri.Margin = new System.Windows.Forms.Padding(5);
            this.btnGeri.Name = "btnGeri";
            this.btnGeri.Size = new System.Drawing.Size(304, 76);
            this.btnGeri.TabIndex = 4;
            this.btnGeri.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnGeri.Click += new System.EventHandler(this.btnGeri_Click);
            // 
            // FrmSınav
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.ClientSize = new System.Drawing.Size(1034, 748);
            this.Controls.Add(this.btnGeri);
            this.Controls.Add(this.btnBasla);
            this.Controls.Add(this.bunifuCustomLabel2);
            this.Controls.Add(this.bunifuCustomLabel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FrmSınav";
            this.Text = "FrmSınav";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel1;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel2;
        private Bunifu.Framework.UI.BunifuThinButton2 btnBasla;
        private Bunifu.Framework.UI.BunifuThinButton2 btnGeri;
    }
}