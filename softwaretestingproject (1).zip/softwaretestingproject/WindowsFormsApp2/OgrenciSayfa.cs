﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using windowsFormsApp1;

namespace WindowsFormsApp2
{
    public partial class OgrenciSayfa : Form
    {
        public OgrenciSayfa()
        {
            InitializeComponent();
        }

        private void btnSınav_Click(object sender, EventArgs e)
        {
            this.Hide();
            FrmSınav fm = new FrmSınav();
            fm.Show();
        }

        private void btnSonuc_Click(object sender, EventArgs e)
        {
            this.Hide();
            FrmSonuc fm = new FrmSonuc();
            fm.Show();
        }

        private void btnGeri_Click(object sender, EventArgs e)
        {
            this.Close();
            Form1 fm = new Form1();
            fm.Show();
        }
    }
}
