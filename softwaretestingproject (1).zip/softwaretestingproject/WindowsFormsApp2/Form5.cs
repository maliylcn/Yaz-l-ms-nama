﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data;
using MySql.Data.MySqlClient;
using windowsFormsApp1;

namespace WwindowsFormsApp1
{
    public partial class Form5 : Form
    {

        public MySqlConnection con = new MySqlConnection("Server=localhost;Database=exam;Uid=root;Pwd='';");
        MySqlDataReader dr;
        MySqlCommand cmd;


        public Form5()
        {
            InitializeComponent();
        }

        private void Form5_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'examDataSet1.subjects' table. You can move, or remove it, as needed.
            this.subjectsTableAdapter.Fill(this.examDataSet1.subjects);

        }

        private void btnSoruEkle_Click(object sender, EventArgs e)
        {
            con.Open();
            cmd = new MySqlCommand("Insert into sorular(questions,cevap1,cevap2,cevap3,cevap4,sonuc,subjects_id) values ('" + txtSoruMetin.Text + "','" + txtSıkA.Text + "','" + txtSıkB.Text + "','" + txtSıkC.Text + "','" + txtSıkD.Text + "','" + txtSıkDogru.Text + "','" + cboxSubject.SelectedValue + "')", con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Ekleme başarılı...");
            con.Close();
            txtSoruMetin.Text = "";
            txtSıkA.Text = "";
            txtSıkB.Text = "";
            txtSıkC.Text = "";
            txtSıkD.Text = "";
            txtSıkDogru.Text = "";

        }

        private void btnGeriDon_Click(object sender, EventArgs e)
        {
            this.Close();
            Form4 fm = new Form4();
            fm.Show();
        }
    }
}
