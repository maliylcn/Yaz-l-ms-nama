﻿namespace WindowsFormsApp2
{
    partial class FormSoruCikar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormSoruCikar));
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.idDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.questionsDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cevap1DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cevap2DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cevap3DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cevap4DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sonucDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.subjectsidDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sorularBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.examDataSet2 = new WindowsFormsApp2.examDataSet2();
            this.sorularTableAdapter = new WindowsFormsApp2.examDataSet2TableAdapters.sorularTableAdapter();
            this.btnSil = new Bunifu.Framework.UI.BunifuThinButton2();
            this.bunifuCustomLabel1 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.txtSoruId = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.btnGeriDon = new Bunifu.Framework.UI.BunifuThinButton2();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sorularBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.examDataSet2)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn,
            this.questionsDataGridViewTextBoxColumn,
            this.cevap1DataGridViewTextBoxColumn,
            this.cevap2DataGridViewTextBoxColumn,
            this.cevap3DataGridViewTextBoxColumn,
            this.cevap4DataGridViewTextBoxColumn,
            this.sonucDataGridViewTextBoxColumn,
            this.subjectsidDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.sorularBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(12, 12);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 82;
            this.dataGridView1.RowTemplate.Height = 33;
            this.dataGridView1.Size = new System.Drawing.Size(1684, 462);
            this.dataGridView1.TabIndex = 0;
            // 
            // idDataGridViewTextBoxColumn
            // 
            this.idDataGridViewTextBoxColumn.DataPropertyName = "id";
            this.idDataGridViewTextBoxColumn.HeaderText = "id";
            this.idDataGridViewTextBoxColumn.MinimumWidth = 10;
            this.idDataGridViewTextBoxColumn.Name = "idDataGridViewTextBoxColumn";
            this.idDataGridViewTextBoxColumn.Width = 200;
            // 
            // questionsDataGridViewTextBoxColumn
            // 
            this.questionsDataGridViewTextBoxColumn.DataPropertyName = "questions";
            this.questionsDataGridViewTextBoxColumn.HeaderText = "questions";
            this.questionsDataGridViewTextBoxColumn.MinimumWidth = 10;
            this.questionsDataGridViewTextBoxColumn.Name = "questionsDataGridViewTextBoxColumn";
            this.questionsDataGridViewTextBoxColumn.Width = 200;
            // 
            // cevap1DataGridViewTextBoxColumn
            // 
            this.cevap1DataGridViewTextBoxColumn.DataPropertyName = "cevap1";
            this.cevap1DataGridViewTextBoxColumn.HeaderText = "cevap1";
            this.cevap1DataGridViewTextBoxColumn.MinimumWidth = 10;
            this.cevap1DataGridViewTextBoxColumn.Name = "cevap1DataGridViewTextBoxColumn";
            this.cevap1DataGridViewTextBoxColumn.Width = 200;
            // 
            // cevap2DataGridViewTextBoxColumn
            // 
            this.cevap2DataGridViewTextBoxColumn.DataPropertyName = "cevap2";
            this.cevap2DataGridViewTextBoxColumn.HeaderText = "cevap2";
            this.cevap2DataGridViewTextBoxColumn.MinimumWidth = 10;
            this.cevap2DataGridViewTextBoxColumn.Name = "cevap2DataGridViewTextBoxColumn";
            this.cevap2DataGridViewTextBoxColumn.Width = 200;
            // 
            // cevap3DataGridViewTextBoxColumn
            // 
            this.cevap3DataGridViewTextBoxColumn.DataPropertyName = "cevap3";
            this.cevap3DataGridViewTextBoxColumn.HeaderText = "cevap3";
            this.cevap3DataGridViewTextBoxColumn.MinimumWidth = 10;
            this.cevap3DataGridViewTextBoxColumn.Name = "cevap3DataGridViewTextBoxColumn";
            this.cevap3DataGridViewTextBoxColumn.Width = 200;
            // 
            // cevap4DataGridViewTextBoxColumn
            // 
            this.cevap4DataGridViewTextBoxColumn.DataPropertyName = "cevap4";
            this.cevap4DataGridViewTextBoxColumn.HeaderText = "cevap4";
            this.cevap4DataGridViewTextBoxColumn.MinimumWidth = 10;
            this.cevap4DataGridViewTextBoxColumn.Name = "cevap4DataGridViewTextBoxColumn";
            this.cevap4DataGridViewTextBoxColumn.Width = 200;
            // 
            // sonucDataGridViewTextBoxColumn
            // 
            this.sonucDataGridViewTextBoxColumn.DataPropertyName = "sonuc";
            this.sonucDataGridViewTextBoxColumn.HeaderText = "sonuc";
            this.sonucDataGridViewTextBoxColumn.MinimumWidth = 10;
            this.sonucDataGridViewTextBoxColumn.Name = "sonucDataGridViewTextBoxColumn";
            this.sonucDataGridViewTextBoxColumn.Width = 200;
            // 
            // subjectsidDataGridViewTextBoxColumn
            // 
            this.subjectsidDataGridViewTextBoxColumn.DataPropertyName = "subjects_id";
            this.subjectsidDataGridViewTextBoxColumn.HeaderText = "subjects_id";
            this.subjectsidDataGridViewTextBoxColumn.MinimumWidth = 10;
            this.subjectsidDataGridViewTextBoxColumn.Name = "subjectsidDataGridViewTextBoxColumn";
            this.subjectsidDataGridViewTextBoxColumn.Width = 200;
            // 
            // sorularBindingSource
            // 
            this.sorularBindingSource.DataMember = "sorular";
            this.sorularBindingSource.DataSource = this.examDataSet2;
            // 
            // examDataSet2
            // 
            this.examDataSet2.DataSetName = "examDataSet2";
            this.examDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // sorularTableAdapter
            // 
            this.sorularTableAdapter.ClearBeforeFill = true;
            // 
            // btnSil
            // 
            this.btnSil.ActiveBorderThickness = 1;
            this.btnSil.ActiveCornerRadius = 20;
            this.btnSil.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.btnSil.ActiveForecolor = System.Drawing.Color.White;
            this.btnSil.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.btnSil.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btnSil.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSil.BackgroundImage")));
            this.btnSil.ButtonText = "SORUYU SİL";
            this.btnSil.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSil.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSil.ForeColor = System.Drawing.Color.SeaGreen;
            this.btnSil.IdleBorderThickness = 1;
            this.btnSil.IdleCornerRadius = 20;
            this.btnSil.IdleFillColor = System.Drawing.Color.White;
            this.btnSil.IdleForecolor = System.Drawing.Color.SeaGreen;
            this.btnSil.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.btnSil.Location = new System.Drawing.Point(749, 490);
            this.btnSil.Margin = new System.Windows.Forms.Padding(5);
            this.btnSil.Name = "btnSil";
            this.btnSil.Size = new System.Drawing.Size(947, 209);
            this.btnSil.TabIndex = 1;
            this.btnSil.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnSil.Click += new System.EventHandler(this.btnSil_Click);
            // 
            // bunifuCustomLabel1
            // 
            this.bunifuCustomLabel1.AutoSize = true;
            this.bunifuCustomLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel1.Location = new System.Drawing.Point(12, 518);
            this.bunifuCustomLabel1.Name = "bunifuCustomLabel1";
            this.bunifuCustomLabel1.Size = new System.Drawing.Size(297, 37);
            this.bunifuCustomLabel1.TabIndex = 2;
            this.bunifuCustomLabel1.Text = "SORU İD GİRİNİZ:";
            // 
            // txtSoruId
            // 
            this.txtSoruId.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtSoruId.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtSoruId.characterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtSoruId.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtSoruId.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.txtSoruId.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtSoruId.HintForeColor = System.Drawing.Color.Empty;
            this.txtSoruId.HintText = "";
            this.txtSoruId.isPassword = false;
            this.txtSoruId.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtSoruId.LineIdleColor = System.Drawing.Color.Gray;
            this.txtSoruId.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtSoruId.LineThickness = 3;
            this.txtSoruId.Location = new System.Drawing.Point(351, 490);
            this.txtSoruId.Margin = new System.Windows.Forms.Padding(4);
            this.txtSoruId.MaxLength = 32767;
            this.txtSoruId.Name = "txtSoruId";
            this.txtSoruId.Size = new System.Drawing.Size(379, 65);
            this.txtSoruId.TabIndex = 3;
            this.txtSoruId.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // btnGeriDon
            // 
            this.btnGeriDon.ActiveBorderThickness = 1;
            this.btnGeriDon.ActiveCornerRadius = 20;
            this.btnGeriDon.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.btnGeriDon.ActiveForecolor = System.Drawing.Color.White;
            this.btnGeriDon.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.btnGeriDon.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btnGeriDon.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnGeriDon.BackgroundImage")));
            this.btnGeriDon.ButtonText = "GERİ DÖN";
            this.btnGeriDon.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnGeriDon.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGeriDon.ForeColor = System.Drawing.Color.SeaGreen;
            this.btnGeriDon.IdleBorderThickness = 1;
            this.btnGeriDon.IdleCornerRadius = 20;
            this.btnGeriDon.IdleFillColor = System.Drawing.Color.White;
            this.btnGeriDon.IdleForecolor = System.Drawing.Color.SeaGreen;
            this.btnGeriDon.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.btnGeriDon.Location = new System.Drawing.Point(19, 596);
            this.btnGeriDon.Margin = new System.Windows.Forms.Padding(5);
            this.btnGeriDon.Name = "btnGeriDon";
            this.btnGeriDon.Size = new System.Drawing.Size(711, 103);
            this.btnGeriDon.TabIndex = 4;
            this.btnGeriDon.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnGeriDon.Click += new System.EventHandler(this.btnGeriDon_Click);
            // 
            // FormSoruCikar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.ClientSize = new System.Drawing.Size(1728, 774);
            this.Controls.Add(this.btnGeriDon);
            this.Controls.Add(this.txtSoruId);
            this.Controls.Add(this.bunifuCustomLabel1);
            this.Controls.Add(this.btnSil);
            this.Controls.Add(this.dataGridView1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FormSoruCikar";
            this.Text = "FormSoruCikar";
            this.Load += new System.EventHandler(this.FormSoruCikar_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sorularBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.examDataSet2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private examDataSet2 examDataSet2;
        private System.Windows.Forms.BindingSource sorularBindingSource;
        private examDataSet2TableAdapters.sorularTableAdapter sorularTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn questionsDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cevap1DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cevap2DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cevap3DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cevap4DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sonucDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn subjectsidDataGridViewTextBoxColumn;
        private Bunifu.Framework.UI.BunifuThinButton2 btnSil;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel1;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtSoruId;
        private Bunifu.Framework.UI.BunifuThinButton2 btnGeriDon;
    }
}