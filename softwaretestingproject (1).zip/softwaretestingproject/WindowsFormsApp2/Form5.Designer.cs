﻿namespace WwindowsFormsApp1
{
    partial class Form5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form5));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnGeriDon = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btnSoruEkle = new Bunifu.Framework.UI.BunifuThinButton2();
            this.cboxSubject = new System.Windows.Forms.ComboBox();
            this.subjectsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.examDataSet1 = new WindowsFormsApp2.examDataSet1();
            this.bunifuCustomLabel2 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.button1 = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtSıkDogru = new System.Windows.Forms.TextBox();
            this.txtSıkD = new System.Windows.Forms.TextBox();
            this.txtSıkC = new System.Windows.Forms.TextBox();
            this.txtSıkB = new System.Windows.Forms.TextBox();
            this.txtSıkA = new System.Windows.Forms.TextBox();
            this.txtSoruMetin = new System.Windows.Forms.TextBox();
            this.subjectsTableAdapter = new WindowsFormsApp2.examDataSet1TableAdapters.subjectsTableAdapter();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.subjectsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.examDataSet1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.groupBox1.Controls.Add(this.btnGeriDon);
            this.groupBox1.Controls.Add(this.btnSoruEkle);
            this.groupBox1.Controls.Add(this.cboxSubject);
            this.groupBox1.Controls.Add(this.bunifuCustomLabel2);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.txtSıkDogru);
            this.groupBox1.Controls.Add(this.txtSıkD);
            this.groupBox1.Controls.Add(this.txtSıkC);
            this.groupBox1.Controls.Add(this.txtSıkB);
            this.groupBox1.Controls.Add(this.txtSıkA);
            this.groupBox1.Controls.Add(this.txtSoruMetin);
            this.groupBox1.Location = new System.Drawing.Point(-6, -27);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(6);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(6);
            this.groupBox1.Size = new System.Drawing.Size(1204, 613);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "groupBox1";
            // 
            // btnGeriDon
            // 
            this.btnGeriDon.ActiveBorderThickness = 1;
            this.btnGeriDon.ActiveCornerRadius = 20;
            this.btnGeriDon.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.btnGeriDon.ActiveForecolor = System.Drawing.Color.White;
            this.btnGeriDon.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.btnGeriDon.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btnGeriDon.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnGeriDon.BackgroundImage")));
            this.btnGeriDon.ButtonText = "GERİ DÖN";
            this.btnGeriDon.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnGeriDon.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGeriDon.ForeColor = System.Drawing.Color.SeaGreen;
            this.btnGeriDon.IdleBorderThickness = 1;
            this.btnGeriDon.IdleCornerRadius = 20;
            this.btnGeriDon.IdleFillColor = System.Drawing.Color.White;
            this.btnGeriDon.IdleForecolor = System.Drawing.Color.SeaGreen;
            this.btnGeriDon.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.btnGeriDon.Location = new System.Drawing.Point(67, 508);
            this.btnGeriDon.Margin = new System.Windows.Forms.Padding(5);
            this.btnGeriDon.Name = "btnGeriDon";
            this.btnGeriDon.Size = new System.Drawing.Size(527, 69);
            this.btnGeriDon.TabIndex = 12;
            this.btnGeriDon.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnGeriDon.Click += new System.EventHandler(this.btnGeriDon_Click);
            // 
            // btnSoruEkle
            // 
            this.btnSoruEkle.ActiveBorderThickness = 1;
            this.btnSoruEkle.ActiveCornerRadius = 20;
            this.btnSoruEkle.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.btnSoruEkle.ActiveForecolor = System.Drawing.Color.White;
            this.btnSoruEkle.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.btnSoruEkle.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btnSoruEkle.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSoruEkle.BackgroundImage")));
            this.btnSoruEkle.ButtonText = "SORU EKLE";
            this.btnSoruEkle.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSoruEkle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSoruEkle.ForeColor = System.Drawing.Color.SeaGreen;
            this.btnSoruEkle.IdleBorderThickness = 1;
            this.btnSoruEkle.IdleCornerRadius = 20;
            this.btnSoruEkle.IdleFillColor = System.Drawing.Color.White;
            this.btnSoruEkle.IdleForecolor = System.Drawing.Color.SeaGreen;
            this.btnSoruEkle.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.btnSoruEkle.Location = new System.Drawing.Point(604, 508);
            this.btnSoruEkle.Margin = new System.Windows.Forms.Padding(5);
            this.btnSoruEkle.Name = "btnSoruEkle";
            this.btnSoruEkle.Size = new System.Drawing.Size(524, 69);
            this.btnSoruEkle.TabIndex = 11;
            this.btnSoruEkle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnSoruEkle.Click += new System.EventHandler(this.btnSoruEkle_Click);
            // 
            // cboxSubject
            // 
            this.cboxSubject.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.subjectsBindingSource, "subject", true));
            this.cboxSubject.DataSource = this.subjectsBindingSource;
            this.cboxSubject.DisplayMember = "subject";
            this.cboxSubject.FormattingEnabled = true;
            this.cboxSubject.Location = new System.Drawing.Point(837, 427);
            this.cboxSubject.Name = "cboxSubject";
            this.cboxSubject.Size = new System.Drawing.Size(291, 33);
            this.cboxSubject.TabIndex = 10;
            this.cboxSubject.ValueMember = "id";
            // 
            // subjectsBindingSource
            // 
            this.subjectsBindingSource.DataMember = "subjects";
            this.subjectsBindingSource.DataSource = this.examDataSet1;
            // 
            // examDataSet1
            // 
            this.examDataSet1.DataSetName = "examDataSet1";
            this.examDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // bunifuCustomLabel2
            // 
            this.bunifuCustomLabel2.AutoSize = true;
            this.bunifuCustomLabel2.Location = new System.Drawing.Point(599, 427);
            this.bunifuCustomLabel2.Name = "bunifuCustomLabel2";
            this.bunifuCustomLabel2.Size = new System.Drawing.Size(223, 25);
            this.bunifuCustomLabel2.TabIndex = 8;
            this.bunifuCustomLabel2.Text = "ALT BAŞLIK SEÇİNİZ:";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(0, 0);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 13;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label6.Location = new System.Drawing.Point(62, 42);
            this.label6.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(160, 26);
            this.label6.TabIndex = 2;
            this.label6.Text = "Soru Metnini :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label5.Location = new System.Drawing.Point(72, 429);
            this.label5.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(124, 26);
            this.label5.TabIndex = 1;
            this.label5.Text = "Doğru Şık:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.Location = new System.Drawing.Point(673, 355);
            this.label4.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(77, 26);
            this.label4.TabIndex = 1;
            this.label4.Text = "Şık D:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.Location = new System.Drawing.Point(72, 364);
            this.label3.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(77, 26);
            this.label3.TabIndex = 1;
            this.label3.Text = "Şık C:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.Location = new System.Drawing.Point(674, 295);
            this.label2.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(76, 26);
            this.label2.TabIndex = 1;
            this.label2.Text = "Şık B:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(72, 296);
            this.label1.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(76, 26);
            this.label1.TabIndex = 1;
            this.label1.Text = "Şık A:";
            // 
            // txtSıkDogru
            // 
            this.txtSıkDogru.Location = new System.Drawing.Point(234, 427);
            this.txtSıkDogru.Margin = new System.Windows.Forms.Padding(6);
            this.txtSıkDogru.Name = "txtSıkDogru";
            this.txtSıkDogru.Size = new System.Drawing.Size(292, 31);
            this.txtSıkDogru.TabIndex = 0;
            // 
            // txtSıkD
            // 
            this.txtSıkD.Location = new System.Drawing.Point(835, 341);
            this.txtSıkD.Margin = new System.Windows.Forms.Padding(6);
            this.txtSıkD.Name = "txtSıkD";
            this.txtSıkD.Size = new System.Drawing.Size(292, 31);
            this.txtSıkD.TabIndex = 0;
            // 
            // txtSıkC
            // 
            this.txtSıkC.Location = new System.Drawing.Point(234, 350);
            this.txtSıkC.Margin = new System.Windows.Forms.Padding(6);
            this.txtSıkC.Name = "txtSıkC";
            this.txtSıkC.Size = new System.Drawing.Size(292, 31);
            this.txtSıkC.TabIndex = 0;
            // 
            // txtSıkB
            // 
            this.txtSıkB.Location = new System.Drawing.Point(836, 289);
            this.txtSıkB.Margin = new System.Windows.Forms.Padding(6);
            this.txtSıkB.Name = "txtSıkB";
            this.txtSıkB.Size = new System.Drawing.Size(292, 31);
            this.txtSıkB.TabIndex = 0;
            // 
            // txtSıkA
            // 
            this.txtSıkA.Location = new System.Drawing.Point(234, 290);
            this.txtSıkA.Margin = new System.Windows.Forms.Padding(6);
            this.txtSıkA.Name = "txtSıkA";
            this.txtSıkA.Size = new System.Drawing.Size(292, 31);
            this.txtSıkA.TabIndex = 0;
            // 
            // txtSoruMetin
            // 
            this.txtSoruMetin.Location = new System.Drawing.Point(234, 42);
            this.txtSoruMetin.Margin = new System.Windows.Forms.Padding(6);
            this.txtSoruMetin.Multiline = true;
            this.txtSoruMetin.Name = "txtSoruMetin";
            this.txtSoruMetin.Size = new System.Drawing.Size(892, 211);
            this.txtSoruMetin.TabIndex = 0;
            // 
            // subjectsTableAdapter
            // 
            this.subjectsTableAdapter.ClearBeforeFill = true;
            // 
            // Form5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1200, 582);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "Form5";
            this.Text = "Form5";
            this.Load += new System.EventHandler(this.Form5_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.subjectsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.examDataSet1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtSıkDogru;
        private System.Windows.Forms.TextBox txtSıkD;
        private System.Windows.Forms.TextBox txtSıkC;
        private System.Windows.Forms.TextBox txtSıkB;
        private System.Windows.Forms.TextBox txtSıkA;
        private System.Windows.Forms.TextBox txtSoruMetin;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label6;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel2;
        private WindowsFormsApp2.examDataSet1 examDataSet1;
        private System.Windows.Forms.BindingSource subjectsBindingSource;
        private WindowsFormsApp2.examDataSet1TableAdapters.subjectsTableAdapter subjectsTableAdapter;
        private System.Windows.Forms.ComboBox cboxSubject;
        private Bunifu.Framework.UI.BunifuThinButton2 btnGeriDon;
        private Bunifu.Framework.UI.BunifuThinButton2 btnSoruEkle;
    }
}