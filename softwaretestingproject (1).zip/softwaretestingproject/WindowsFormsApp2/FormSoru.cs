﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using MySql.Data;

namespace WindowsFormsApp2
{
    
    public partial class FormSoru : Form
    {
        public MySqlConnection con = new MySqlConnection("Server=localhost;Database=exam;Uid=root;Pwd='';");
        MySqlDataReader dr;
        MySqlCommand cmd;
        
        public FormSoru()
        {
            InitializeComponent();
        }
        private void FormSoru_Load(object sender, EventArgs e)
        {
           
        }
        private void btnDogrula_Click(object sender, EventArgs e)
        {
            con.Open();
            cmd = new MySqlCommand("Insert into sonuclar(sinav_id,cvp1,cvp2,cvp3,cvp4,cvp5,cvp6,cvp7,cvp8,cvp9,cvp10) values ('" +txtSınavId.Text + "','" + txtSoru1Cvp.Text + "','" + txtSoru2Cvp.Text + "','" + txtSoru3Cvp.Text + "'," + txtSoru4Cvp.Text + "','" + txtSoru5Cvp.Text + "','" + txtSoru6Cvp.Text + "'," + txtSoru7Cvp.Text + "','" + txtSoru8Cvp.Text + "','" + txtSoru9Cvp.Text + "','" + txtSoru10Cvp.Text + "')", con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Cevaplarınız Kaydedilmiştir Sonuçlardan Kontrol Edebilirsiniz...");
            con.Close();
            txtSınavId.Text = "";
            txtSoruID.Text = "";
            txtSoru1Cvp.Text = "";
            txtSoru2Cvp.Text = "";
            txtSoru3Cvp.Text = "";
            txtSoru4Cvp.Text = "";
            txtSoru5Cvp.Text = "";
            txtSoru6Cvp.Text = "";
            txtSoru7Cvp.Text = "";
            txtSoru8Cvp.Text = "";
            txtSoru9Cvp.Text = "";
            txtSoru10Cvp.Text = "";
        }

        private void btnCık_Click(object sender, EventArgs e)
        {
            this.Close();
            FrmSınav fm = new FrmSınav();
            fm.Show();

        }

        private void btnSinavSec_Click(object sender, EventArgs e)
        {
            con.Open();
            string kayit = "SELECT * from sınav where id = '" + txtSınavId.Text + "'";
            //musteriler tablosundaki tüm kayıtları çekecek olan sql sorgusu.
            MySqlCommand komut = new MySqlCommand(kayit, con);
            //Sorgumuzu ve baglantimizi parametre olarak alan bir SqlCommand nesnesi oluşturuyoruz.
            MySqlDataAdapter da = new MySqlDataAdapter(komut);
            //SqlDataAdapter sınıfı verilerin databaseden aktarılması işlemini gerçekleştirir.
            DataTable dt = new DataTable();
            da.Fill(dt);
            dtGridSoru.DataSource = dt;
            //Formumuzdaki DataGridViewin veri kaynağını oluşturduğumuz tablo olarak gösteriyoruz.
            con.Close();

        }

        private void btnSoruGetir_Click(object sender, EventArgs e)
        {
            con.Open();
            string kayit = "SELECT questions,cevap1,cevap2,cevap3,cevap4 from sorular where id = '" + txtSoruID.Text + "'";
            //musteriler tablosundaki tüm kayıtları çekecek olan sql sorgusu.
            MySqlCommand komut = new MySqlCommand(kayit, con);
            //Sorgumuzu ve baglantimizi parametre olarak alan bir SqlCommand nesnesi oluşturuyoruz.
            MySqlDataAdapter da = new MySqlDataAdapter(komut);
            //SqlDataAdapter sınıfı verilerin databaseden aktarılması işlemini gerçekleştirir.
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            //Formumuzdaki DataGridViewin veri kaynağını oluşturduğumuz tablo olarak gösteriyoruz.
            con.Close();
        }


    }
}
